public class EagerMain {
    // prove that its eager
     public static void main(String[] args) {
         System.out.println("Program started in EagerMain class");
     }

}
