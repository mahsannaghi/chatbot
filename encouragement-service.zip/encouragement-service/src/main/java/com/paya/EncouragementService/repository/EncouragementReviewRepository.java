package com.paya.EncouragementService.repository;

import com.paya.EncouragementService.entity.EncouragementReview;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface EncouragementReviewRepository extends JpaRepository<EncouragementReview, UUID>, JpaSpecificationExecutor<EncouragementReview> {
    List<EncouragementReview> findAllByEncouragementReviewTypeAndEncouragementReviewEncouragementId(Integer encouragementReviewType, UUID encouragementId);
    Optional<EncouragementReview> findByEncouragementReviewRegistrarOrganizationIdAndEncouragementReviewEncouragementIdAndEncouragementReviewResult(String encouragementRegistrarOrganizationId, UUID encouragementId, int reviewResultEnum);
}
