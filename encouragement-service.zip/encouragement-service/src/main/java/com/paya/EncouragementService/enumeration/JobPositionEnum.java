package com.paya.EncouragementService.enumeration;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum JobPositionEnum {
    JOB_POSITION_18(0, "جایگاه شغلی 18"),
    JOB_POSITION_19(1, "جایگاه شغلی 19"),
    JOB_POSITION_110(2, "جایگاه شغلی 110"),
    JOB_POSITION_111(3, "جایگاه شغلی 111"),
    JOB_POSITION_112(4, "جایگاه شغلی 112"),
    JOB_POSITION_113(5, "جایگاه شغلی 113"),
    JOB_POSITION_114(6, "جایگاه شغلی 114"),
    JOB_POSITION_115(7, "جایگاه شغلی 115"),
    JOB_POSITION_116(8, "جایگاه شغلی 116"),
    JOB_POSITION_117(9, "جایگاه شغلی 117"),
    JOB_POSITION_118(10, "جایگاه شغلی 118"),
    JOB_POSITION_119(11, "جایگاه شغلی 119"),
    JOB_POSITION_120(12, "جایگاه شغلی 120"),
    JOB_POSITION_125(13, "جایگاه شغلی 125"),
    JOB_POSITION_130(14, "جایگاه شغلی 130"),

    JOB_POSITION_28(15, "جایگاه شغلی 28"),
    JOB_POSITION_29(16, "جایگاه شغلی 29"),
    JOB_POSITION_210(17, "جایگاه شغلی 210"),
    JOB_POSITION_211(18, "جایگاه شغلی 211"),
    JOB_POSITION_212(19, "جایگاه شغلی 212"),
    JOB_POSITION_213(20, "جایگاه شغلی 213"),
    JOB_POSITION_214(21, "جایگاه شغلی 214"),
    JOB_POSITION_215(22, "جایگاه شغلی 215"),
    JOB_POSITION_216(23, "جایگاه شغلی 216"),
    JOB_POSITION_217(24, "جایگاه شغلی 217"),
    JOB_POSITION_218(25, "جایگاه شغلی 218"),
    JOB_POSITION_219(26, "جایگاه شغلی 219"),
    JOB_POSITION_220(27, "جایگاه شغلی 220"),
    JOB_POSITION_225(28, "جایگاه شغلی 225"),
    JOB_POSITION_230(29, "جایگاه شغلی 230"),

    JOB_POSITION_38(30, "جایگاه شغلی 38"),
    JOB_POSITION_39(31, "جایگاه شغلی 39"),
    JOB_POSITION_310(32, "جایگاه شغلی 310"),
    JOB_POSITION_311(33, "جایگاه شغلی 311"),
    JOB_POSITION_312(34, "جایگاه شغلی 312"),
    JOB_POSITION_313(35, "جایگاه شغلی 313"),
    JOB_POSITION_314(36, "جایگاه شغلی 314"),
    JOB_POSITION_315(37, "جایگاه شغلی 315"),
    JOB_POSITION_316(38, "جایگاه شغلی 316"),
    JOB_POSITION_317(39, "جایگاه شغلی 317"),
    JOB_POSITION_318(40, "جایگاه شغلی 318"),
    JOB_POSITION_319(41, "جایگاه شغلی 319"),
    JOB_POSITION_320(42, "جایگاه شغلی 320"),
    JOB_POSITION_325(43, "جایگاه شغلی 325"),
    JOB_POSITION_330(44, "جایگاه شغلی 330"),

    JOB_POSITION_48(45, "جایگاه شغلی 48"),
    JOB_POSITION_49(46, "جایگاه شغلی 49"),
    JOB_POSITION_410(47, "جایگاه شغلی 410"),
    JOB_POSITION_411(46, "جایگاه شغلی 411"),
    JOB_POSITION_412(49, "جایگاه شغلی 412"),
    JOB_POSITION_413(50, "جایگاه شغلی 413"),
    JOB_POSITION_414(51, "جایگاه شغلی 414"),
    JOB_POSITION_415(52, "جایگاه شغلی 415"),
    JOB_POSITION_416(53, "جایگاه شغلی 416"),
    JOB_POSITION_417(54, "جایگاه شغلی 417"),
    JOB_POSITION_418(55, "جایگاه شغلی 418"),
    JOB_POSITION_419(56, "جایگاه شغلی 419"),
    JOB_POSITION_420(57, "جایگاه شغلی 420"),
    JOB_POSITION_425(58, "جایگاه شغلی 425"),
    JOB_POSITION_430(59, "جایگاه شغلی 430"),

    JOB_POSITION_58(60, "جایگاه شغلی 58"),
    JOB_POSITION_59(61, "جایگاه شغلی 59"),
    JOB_POSITION_510(62, "جایگاه شغلی 510"),
    JOB_POSITION_511(63, "جایگاه شغلی 511"),
    JOB_POSITION_512(64, "جایگاه شغلی 512"),
    JOB_POSITION_513(65, "جایگاه شغلی 513"),
    JOB_POSITION_514(66, "جایگاه شغلی 514"),
    JOB_POSITION_515(67, "جایگاه شغلی 515"),
    JOB_POSITION_516(68, "جایگاه شغلی 516"),
    JOB_POSITION_517(69, "جایگاه شغلی 517"),
    JOB_POSITION_518(70, "جایگاه شغلی 518"),
    JOB_POSITION_519(71, "جایگاه شغلی 519"),
    JOB_POSITION_520(72, "جایگاه شغلی 520"),
    JOB_POSITION_525(73, "جایگاه شغلی 525"),
    JOB_POSITION_530(74, "جایگاه شغلی 530");
    private final int code;
    private final String persianName;

    public int getCode() {
        return code;
    }

    public static JobPositionEnum fromCode(int code) {
        for (JobPositionEnum draft : JobPositionEnum.values()) {
            if (draft.getCode() == code) {
                return draft;
            }
        }
        throw new IllegalArgumentException("Invalid code: " + code);
    }
}
