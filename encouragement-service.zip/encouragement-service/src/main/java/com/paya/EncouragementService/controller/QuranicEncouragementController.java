package com.paya.EncouragementService.controller;

import com.paya.EncouragementService.dto.QuranicEncouragementInsertDTO;
import com.paya.EncouragementService.dto.v2.QuranicEncouragementDTOV2;
import com.paya.EncouragementService.dto.v2.QuranicEncouragementFilterDTOV2;
import com.paya.EncouragementService.entity.QuranicEncouragement;
import com.paya.EncouragementService.service.QuranicEncouragementService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/api/quranic-encouragement")
@PreAuthorize("hasAnyRole('Manager')")
public class QuranicEncouragementController {

    @Autowired
    private QuranicEncouragementService service;


    @PostMapping
    public QuranicEncouragementInsertDTO createQuranicEncouragement(@RequestPart(name = "data") String dto,
                                                                    @RequestPart(required = false, name = "files") List<MultipartFile> files) throws Exception {
        return service.createQuranicEncouragement(dto, files);
    }

    @PatchMapping("/update")
    public QuranicEncouragement updateQuranicEncouragement(@Valid @RequestBody QuranicEncouragementInsertDTO dto) {
        return service.updateQuranicEncouragement(dto);
    }

    @GetMapping("/{id}")
    public QuranicEncouragement getQuranicEncouragementById(@PathVariable UUID id) {
        return service.getQuranicEncouragementById(id)
                .orElseThrow(() -> new IllegalArgumentException("Quranic Encouragement not found"));
    }


    @DeleteMapping("/{id}")
    public void deleteQuranicEncouragement(@PathVariable UUID id) {
        service.deleteQuranicEncouragement(id);
    }

    //
//    @GetMapping
//    public ResponseEntity<Page<QuranicEncouragementDTOV2>> getQuranicEncouragements(@RequestParam(required = false, defaultValue = "5") Integer pageSize,
//                                                                                    @RequestParam(required = false, defaultValue = "0") Integer pageNumber,
//                                                                                    @RequestParam(required = false) String fromDate,
//                                                                                    @RequestParam(required = false) String toDate,
//                                                                                    @RequestParam(required = false) String quranicSeniorityType,
//                                                                                    @RequestParam(required = false) Integer quranicEncouragementAmount,
//                                                                                    @RequestParam(required = false) String quranicSeniorityAmount
//    ) throws ExecutionException, InterruptedException {
//        Page<QuranicEncouragementDTOV2> res = service.getList(PageRequest.of(pageNumber, pageSize), fromDate, toDate, quranicSeniorityType, quranicEncouragementAmount, quranicSeniorityAmount);
//        return ResponseEntity.ok(res);
//    }
    @PostMapping("/filter")
    public ResponseEntity<Page<QuranicEncouragementDTOV2>> getQuranicEncouragements(@RequestBody QuranicEncouragementFilterDTOV2 quranicEncouragementFilterDTOV2,
                                                                                    @RequestParam(required = false, defaultValue = "5") Integer pageSize,
                                                                                    @RequestParam(required = false, defaultValue = "0") Integer pageNumber
    ) throws Exception {
        Page<QuranicEncouragementDTOV2> res = service.getList(quranicEncouragementFilterDTOV2, pageSize, pageNumber);
        return ResponseEntity.ok(res);
    }

}
