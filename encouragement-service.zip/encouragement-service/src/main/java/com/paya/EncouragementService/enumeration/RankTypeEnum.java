package com.paya.EncouragementService.enumeration;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum RankTypeEnum {
    SOLDIER(0, "سرباز"),
    THIRD_SERGEANT(1, "گروهبان سوم"),
    SECOND_SERGEANT(2, "گروهبان دوم"),
    FIRST_SERGEANT(3, "گروهبان يکم"),
    SECOND_MASTER_SERGEANT(4, "استوار دوم"),
    FIRST_MASTER_SERGEANT(5, "استوار يکم"),
    THIRD_LIEUTENANT(5, "ستوان سوم"),
    SECOND_LIEUTENANT(6, "ستوان دوم"),
    FIRST_LIEUTENANT(7, "ستوان يکم"),
    CAPTAIN(8, "سروان"),
    MAJOR(9, "سرگرد"),
    LIEUTENANT_COLONEL(10, "سرهنگ دوم"),
    COLONEL(11, "سرهنگ تمام"),
    BRIGADIER_GENERAL(12, "سرتیپ دوم"),
    MAJOR_GENERAL(13, "سرتیپ يکم"),
    LIEUTENANT_GENERAL(14, "سرلشکر"),
    GENERAL1(15, "سپهبد"),
    GENERAL2(16, "ارتشبد");

    private final Integer rankCode;
    private final String persianName;


    public static RankTypeEnum fromRankCode(int code) {
        for (RankTypeEnum rank : RankTypeEnum.values()) {
            if (rank.getRankCode() == code) {
                return rank;
            }
        }
        throw new IllegalArgumentException("Invalid code: " + code);
    }


}
