package com.paya.EncouragementService.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.paya.EncouragementService.Specification.QuranicEncouragementSpecification;
import com.paya.EncouragementService.dto.PersonnelDTO;
import com.paya.EncouragementService.dto.QuranicEncouragementDTO;
import com.paya.EncouragementService.dto.QuranicEncouragementInsertDTO;
import com.paya.EncouragementService.dto.v2.AttachmentGetDTO;
import com.paya.EncouragementService.dto.v2.QuranicEncouragementDTOV2;
import com.paya.EncouragementService.dto.v2.QuranicEncouragementFilterDTOV2;
import com.paya.EncouragementService.entity.QuranicEncouragement;
import com.paya.EncouragementService.repository.QuranicEncouragementRepository;
import com.paya.EncouragementService.repository.v2.QuranicEncouragementDAO;
import com.paya.EncouragementService.service.v2.AttachmentService;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import paya.net.exceptionhandler.Exception.GeneralException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class QuranicEncouragementService {


    private final QuranicEncouragementRepository repository;
    private final PersonnelService personnelService;
    private final QuranicEncouragementDAO quranicEncouragementDAO;
    private final AttachmentService attachmentService;

    public QuranicEncouragementService(QuranicEncouragementRepository repository, PersonnelService personnelService, QuranicEncouragementDAO quranicEncouragementDAO, AttachmentService attachmentService) {
        this.repository = repository;
        this.personnelService = personnelService;
        this.quranicEncouragementDAO = quranicEncouragementDAO;
        this.attachmentService = attachmentService;
    }

    @Transactional
    public QuranicEncouragementInsertDTO createQuranicEncouragement(String quranicDTO, List<MultipartFile> files) throws Exception {
        if (quranicDTO != null) {
            ObjectMapper objectMapper = new ObjectMapper();
            QuranicEncouragementInsertDTO dto = objectMapper.readValue(quranicDTO, QuranicEncouragementInsertDTO.class);
            QuranicEncouragement entity = new QuranicEncouragement();
            entity.setQuranicSeniorityId(dto.getQuranicSeniorityId());
            //TODO fill from key clock
            entity.setRegistrarPersonnelId(new UUID(36, 36));
            entity.setRelatedPersonnelId(dto.getRelatedPersonnelId());
            entity.setAmount(dto.getAmount());
            QuranicEncouragement finalEntity = repository.save(entity);
            if (files != null) {
                attachmentService.addAttachmentForQuranicEncouragement(files, finalEntity.getQuranicEncouragementId());
            }
            return dto;
        } else throw new GeneralException("پارامتر ورودی صحیح نمی باشد .");
    }

    public QuranicEncouragement updateQuranicEncouragement(QuranicEncouragementInsertDTO dto) {

        QuranicEncouragement entity = repository.findById(dto.getQuranicEncouragementId()).orElseThrow(() -> new IllegalArgumentException("Entity with ID not found"));


        entity.setQuranicSeniorityId(dto.getQuranicSeniorityId());
        entity.setRegistrarPersonnelId(dto.getRegistrarPersonnelId());
        entity.setRelatedPersonnelId(dto.getRelatedPersonnelId());
        // entity.setCreatedAt(dto.getCreatedAt());
        entity.setCreatedAt(LocalDateTime.now());
        entity.setAmount(dto.getAmount());
        //  entity.setUpdatedAt(dto.getUpdatedAt());
        entity.setUpdatedAt(LocalDateTime.now());


        return repository.save(entity);
    }


    public List<QuranicEncouragementDTO> getQuranicEncouragements(String seniorityId, UUID registrarId, UUID relatedPersonnelId, Integer amount, java.sql.Date createdAt) {

        Specification<QuranicEncouragement> spec = Specification.where(null);

        if (seniorityId != null) {
            spec = spec.and(QuranicEncouragementSpecification.filterBySeniorityId(seniorityId));
        }
        if (amount != null) {
            spec = spec.and(QuranicEncouragementSpecification.filterByAmount(amount));
        }
        if (createdAt != null) {
            spec = spec.and(QuranicEncouragementSpecification.filterByCreatedAt(createdAt));
        }
        if (registrarId != null) {
            spec = spec.and(QuranicEncouragementSpecification.filterByRegistrarId(registrarId));
        }
        if (relatedPersonnelId != null) {
            spec = spec.and(QuranicEncouragementSpecification.filterByRelatedPersonnelId(relatedPersonnelId));
        }

        // اجرای جستجو با فیلترهای اعمال شده
        List<QuranicEncouragement> encouragements = repository.findAll(spec);

        // تبدیل موجودیت‌ها به DTO
        return encouragements.stream().map(this::convertToQuranicEncouragementDTO).collect(Collectors.toList());
    }


    private QuranicEncouragementDTO convertToQuranicEncouragementDTO(QuranicEncouragement quranicEncouragement) {
        QuranicEncouragementDTO dto = new QuranicEncouragementDTO();

        dto.setQuranicEncouragementId(quranicEncouragement.getQuranicEncouragementId());
        dto.setQuranicSeniorityId(quranicEncouragement.getQuranicSeniorityId());
        dto.setAmount(quranicEncouragement.getAmount());
        dto.setCreatedAt(quranicEncouragement.getCreatedAt());
        dto.setUpdatedAt(quranicEncouragement.getUpdatedAt());

        // مقداردهی registrarPersonnelId اگر مقدار نال نبود
        Optional.ofNullable(quranicEncouragement.getRegistrarPersonnelId()).map(id -> personnelService.findByPersonnelIdList(Collections.singletonList(id))).filter(list -> !list.isEmpty()).map(list -> list.get(0)).ifPresent(dto::setRegistrarPersonnelId);

        // مقداردهی relatedPersonnelId اگر مقدار نال نبود
        Optional.ofNullable(quranicEncouragement.getRelatedPersonnelId()).map(id -> personnelService.findByPersonnelIdList(Collections.singletonList(id))).filter(list -> !list.isEmpty()).map(list -> list.get(0)).ifPresent(dto::setRelatedPersonnelId);

        return dto;
    }


    public void deleteQuranicEncouragement(UUID id) {
        repository.deleteById(id);
    }

    public Optional<QuranicEncouragement> getQuranicEncouragementById(UUID id) {
        return repository.findById(id);
    }

    public Page<QuranicEncouragementDTOV2> getList(QuranicEncouragementFilterDTOV2 quranicEncouragementDTO, Integer pageSize, Integer pageNumber) throws Exception {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        Page<QuranicEncouragementDTOV2> resultPage = quranicEncouragementDAO.getList(PageRequest.of(pageNumber, pageSize), quranicEncouragementDTO.getFromDate() != null ? LocalDate.parse(quranicEncouragementDTO.getFromDate(), formatter).atStartOfDay() : null, quranicEncouragementDTO.getToDate() != null ? LocalDate.parse(quranicEncouragementDTO.getToDate(), formatter).atStartOfDay() : null, quranicEncouragementDTO.getQuranicSeniorityType(), quranicEncouragementDTO.getQuranicEncouragementAmount(), quranicEncouragementDTO.getQuranicSeniorityAmount());
        List<QuranicEncouragementDTOV2> resultList = resultPage.getContent();
        List<QuranicEncouragementDTOV2> finalResultList = new ArrayList<>();
        //filtering result with personnel entry
        if (quranicEncouragementDTO.getPersonnel() != null) {
            List<PersonnelDTO> personnelList = personnelService.getFilteredPersonnel(quranicEncouragementDTO.getPersonnel());
            if (!personnelList.isEmpty()) {
                for (QuranicEncouragementDTOV2 dto : resultList) {
                    for (PersonnelDTO person : personnelList) {
                        boolean condition = String.valueOf(dto.getQuranicPersonnelId()).equals(person.getPersonnelId());
                        if (condition) {
                            finalResultList.add(dto);
                        }
                    }
                }
            }
        } else {
            finalResultList.addAll(resultList);
        }
        if (!resultList.isEmpty()) {
            //filling person information and files
            for (QuranicEncouragementDTOV2 dto : resultList) {
                PersonnelDTO personnel = personnelService.findById(dto.getQuranicPersonnelId());
                List<AttachmentGetDTO> attachmentGetDTOList = attachmentService.getAllQuranicEncouragementAttachments(PageRequest.of(0, 9000), dto.getQuranicEncouragementId());
                dto.setFiles(attachmentGetDTOList);
                dto.setPersonnel(personnel);
            }
        }

        return new PageImpl<>(finalResultList, PageRequest.of(pageNumber, pageSize), resultPage.getTotalElements());
    }

}
