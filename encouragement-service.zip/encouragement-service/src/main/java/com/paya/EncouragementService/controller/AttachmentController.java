package com.paya.EncouragementService.controller;


import com.paya.EncouragementService.dto.v2.AttachmentGetDTO;
import com.paya.EncouragementService.entity.Attachment;
import com.paya.EncouragementService.service.v2.AttachmentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import paya.net.exceptionhandler.Exception.GeneralException;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("file")
@Slf4j
@PreAuthorize("hasAnyRole('Manager')")
public class AttachmentController {
    private final AttachmentService attachmentService;

    public AttachmentController(AttachmentService attachmentService) {
        this.attachmentService = attachmentService;
    }

    @PostMapping("upload")
    public ResponseEntity<Attachment> uploadFile(@RequestPart MultipartFile file) throws Exception {
        try {

            return ResponseEntity.ok().body(attachmentService.addAttachment(file));
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new Exception(e.getMessage());
        }
    }


    @GetMapping("download")
    public ResponseEntity<?> getFile(@RequestParam String fileId) throws Exception {
        try {
            Attachment attachment = attachmentService.getAttachmentById(UUID.fromString(fileId));
            String fileName = attachment.getAttachmentName();
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                    .body(attachment.getAttachmentFile());
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new GeneralException("خطا در دانلود فایل ");
        }
    }

    @GetMapping("quranicEncouragementFiles/{quranicEncouragementId}")
    public ResponseEntity<List<AttachmentGetDTO>> getAllQuranicEncouragementFiles(@PathVariable String quranicEncouragementId,
                                                                                  @RequestParam(defaultValue = "5") Integer pageSize,
                                                                                  @RequestParam(defaultValue = "1") Integer pageNumber) throws Exception {
        try {
            return ResponseEntity.ok().body(attachmentService.getAllQuranicEncouragementAttachments(PageRequest.of(pageSize, pageNumber), UUID.fromString(quranicEncouragementId)));
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new Exception(e.getMessage());
        }
    }

    @GetMapping("gradeEncouragementFiles/{gradeEncouragementId}")
    public ResponseEntity<List<AttachmentGetDTO>> getAllGradeEncouragementFiles(@PathVariable String gradeEncouragementId,
                                                                                @RequestParam(defaultValue = "5") Integer pageSize,
                                                                                @RequestParam(defaultValue = "1") Integer pageNumber) throws Exception {
        try {
            return ResponseEntity.ok().body(attachmentService.getAllGradeEncouragementAttachments(PageRequest.of(pageSize, pageNumber), UUID.fromString(gradeEncouragementId)));
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new Exception(e.getMessage());
        }
    }

    @GetMapping
    public ResponseEntity<List<AttachmentGetDTO>> getAllQuranicEncouragementFilesWithId(@RequestParam(defaultValue = "5") Integer pageSize, @RequestParam(defaultValue = "1") Integer pageNumber) throws Exception {
        try {
            return ResponseEntity.ok().body(attachmentService.getAllAttachmentsWithoutFileContent(PageRequest.of(pageSize, pageNumber)));
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new Exception(e.getMessage());
        }
    }


    @DeleteMapping
    public ResponseEntity<Boolean> deleteFile(@RequestParam String fileId) throws Exception {
        try {
            return ResponseEntity.ok().body(attachmentService.deleteAttachment(UUID.fromString(fileId)));
        } catch (Exception e) {
            log.error(e.getMessage());
            throw new Exception(e.getMessage());
        }
    }

}
