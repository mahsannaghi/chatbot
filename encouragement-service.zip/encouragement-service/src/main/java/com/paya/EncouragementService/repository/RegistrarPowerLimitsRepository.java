package com.paya.EncouragementService.repository;

import com.paya.EncouragementService.entity.RegistrarPowerLimits;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface RegistrarPowerLimitsRepository extends JpaRepository<RegistrarPowerLimits, UUID>, JpaSpecificationExecutor<RegistrarPowerLimits> {

    void deleteByEncouragementTypeId(UUID encouragementTypeId);

    List<RegistrarPowerLimits> findByEncouragementTypeId(UUID encouragementTypeId);

    // جستجوی رکورد بر اساس gradeId، jobPositionId و encouragementTypeId
    Optional<RegistrarPowerLimits> findByGradeIdAndJobPositionIdAndEncouragementTypeId(
            UUID gradeId, UUID jobPositionId, UUID encouragementTypeId
    );

    Optional<RegistrarPowerLimits> findByRankTypeCodeAndJobPositionCodeAndEncouragementTypeId(Integer rankTypeCode, Integer jobPositionCode, UUID encouragementTypeId);

    Optional<RegistrarPowerLimits> findByGradeIdAndJobPositionId(UUID gradeId, UUID jobPositionId);


    Boolean existsByRankTypeCodeAndJobPositionCodeAndEncouragementTypeId(Integer rankTypeCode, Integer jobPositionCode, UUID typeId);

//    RegistrarPowerLimits findByRankTypeCodeAndJobPositionCodeAndEncouragementTypeId(Integer rankTypeCode, Integer jobPositionCode, UUID typeId);


    Boolean existsByGradeIdAndJobPositionId(UUID grade, UUID jobPosition);
    List<RegistrarPowerLimits> findByJobPositionCode(Integer jobPositionCode);
    List<RegistrarPowerLimits> findByRankTypeCode(Integer rankCode);

}
