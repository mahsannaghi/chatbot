package com.paya.EncouragementService.service.v2.impl;


import com.paya.EncouragementService.dto.v2.AttachmentGetDTO;
import com.paya.EncouragementService.entity.Attachment;
import com.paya.EncouragementService.mapper.AttachmentMapper;
import com.paya.EncouragementService.repository.AttachmentRepository;
import com.paya.EncouragementService.service.v2.AttachmentService;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import paya.net.exceptionhandler.Exception.GeneralException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

@Service
public class AttachmentServiceImpl implements AttachmentService {
    private final AttachmentRepository attachmentRepository;
    private final AttachmentMapper attachmentMapper;

    public AttachmentServiceImpl(AttachmentRepository attachmentRepository, AttachmentMapper attachmentMapper) {
        this.attachmentRepository = attachmentRepository;
        this.attachmentMapper = attachmentMapper;
    }


    @Override
    @Transactional
    public Attachment addAttachment(MultipartFile multipartFile) throws Exception {
        if (multipartFile != null) {
            Attachment entity = new Attachment();
            entity.setAttachmentName(multipartFile.getOriginalFilename());
            entity.setAttachmentFile(multipartFile.getBytes());
            entity.setAttachmentFile(Base64.getEncoder().encode(multipartFile.getBytes()));
            return attachmentRepository.save(entity);
        } else throw new GeneralException("پارامتر ورودی صحیح نمی باشد .");
    }


    @Override
    @Transactional
    public List<MultipartFile> addAllAttachments(List<MultipartFile> fileList) throws IOException {
        if (fileList != null) {
            Attachment entity = new Attachment();
            for (MultipartFile file : fileList) {
                entity.setAttachmentName(file.getOriginalFilename());
                entity.setAttachmentFile(Base64.getEncoder().encode(file.getBytes()));
                attachmentRepository.save(entity);
            }
            return fileList;
        } else throw new GeneralException("پارامتر ورودی صحیح نمی باشد .");
    }

    @Override
    @Transactional
    public List<Attachment> addAttachmentForQuranicEncouragement(List<MultipartFile> fileList, UUID quranicEncouragementId) throws Exception {
        if (fileList != null && quranicEncouragementId != null) {
            List<Attachment> attachmentList = new ArrayList<>();
            for (MultipartFile file : fileList) {
                Attachment entity = new Attachment();
                entity.setAttachmentQuranicEncouragementId(quranicEncouragementId);
                entity.setAttachmentName(file.getOriginalFilename());
                entity.setAttachmentFile(Base64.getEncoder().encode(file.getBytes()));
                attachmentList.add(entity);
            }
            attachmentRepository.saveAll(attachmentList);
            return attachmentList;

        } else throw new GeneralException("پارامتر های ورودی صحیح نمی باشند . ");
    }

    @Override
    @Transactional
    public List<Attachment> addAttachmentForGradeEncouragement(List<MultipartFile> fileList, UUID gradeEncouragementId) throws Exception {
        if (fileList != null && gradeEncouragementId != null) {
            List<Attachment> attachmentList = new ArrayList<>();
            for (MultipartFile file : fileList) {
                Attachment entity = new Attachment();
                entity.setAttachmentGradeEncouragementId(gradeEncouragementId);
                entity.setAttachmentName(file.getOriginalFilename());
                entity.setAttachmentFile(file.getBytes());
                attachmentList.add(entity);
            }
            attachmentRepository.saveAll(attachmentList);

            return attachmentList;

        } else throw new GeneralException("پارامتر های ورودی صحیح نمی باشند . ");
    }


    @Override
    @Transactional
    public Boolean deleteAttachment(UUID id) {
        if (id != null) {
            if (!this.checkExistsInGradeEncouragement(id) && !this.checkExistsInQuranicEncouragement(id)) {
                attachmentRepository.deleteById(id);
                return true;
            } else return false;
        } else throw new GeneralException("پارامتر ورودی صحیح نمی باشد .");
    }

    @Override
    public Attachment getAttachmentById(UUID id) {
        if (id != null) {
            return attachmentRepository.findById(id).orElseThrow(() -> new GeneralException("فایل مورد نظر یافت نشد ."));
        } else throw new GeneralException("پارامتر ورودی صحیح نمی باشد .");
    }

    @Override
    public Boolean checkExistsInQuranicEncouragement(UUID attachmentId) {
        if (attachmentId != null) {
            if (!attachmentRepository.existsInQuranicEncouragement(attachmentId)) {
                return false;
            } else
                throw new GeneralException("این فایل قبلا در قسمت تشویقات قرآنی استفاده شده است و امکان حذف و ویرایش ندارد .");
        } else throw new GeneralException("پارامتر ورودی صحیح نمی باشد .");

    }

    @Override
    public Boolean checkExistsInGradeEncouragement(UUID attachmentId) {
        if (attachmentId != null) {
            if (!attachmentRepository.existsInGradeEncouragement(attachmentId)) {
                return false;
            } else
                throw new GeneralException("این فایل قبلا در قسمت تشویقات تحصیلی استفاده شده است و امکان حذف و ویرایش ندارد .");
        } else throw new GeneralException("پارامتر ورودی صحیح نمی باشد .");

    }

    @Override
    public List<AttachmentGetDTO> getAllAttachmentsWithoutFileContent(Pageable pageable) {
        return attachmentRepository.getAllAttachmentsWithoutFileContent(pageable);
    }

    @Override
    public List<AttachmentGetDTO> getAllQuranicEncouragementAttachments(Pageable pageable, UUID quranicEncouragementId) {
        return attachmentRepository.getAllQuranicEncouragementAttachmentsWithId(pageable, quranicEncouragementId);
    }

    @Override
    public List<AttachmentGetDTO> getAllGradeEncouragementAttachments(Pageable pageable, UUID gradeEncouragementId) {
        return attachmentRepository.getAllGradeEncouragementAttachmentsWithId(pageable, gradeEncouragementId);
    }
}
