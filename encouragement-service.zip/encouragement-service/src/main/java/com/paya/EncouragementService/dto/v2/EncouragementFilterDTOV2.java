package com.paya.EncouragementService.dto.v2;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldNameConstants;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@FieldNameConstants
public class EncouragementFilterDTOV2 {
    private UUID encouragementId;
    private String encouragementNumber;
    private String encouragementType;
    private String encouragementReason;
    private Long encouragementAmount;
//    private String encouragerOrganizationId;
//    private String encouragementRelatedPersonnelOrganizationId;
    private String encouragementRegistrarOrganizationId;
    private List<String> encouragementRegistrarOrganizationIdList;
    private List<String> encouragementPersonnelOrganizationIdList;
    private String encouragementPersonnelOrganizationId;
    private String encouragedPersonFirstName;
    private String encouragedPersonLastName;
    private String registrarPersonFirstName;
    private String registrarPersonLastName;
    private String encouragedPersonUnitCode;
    private String encouragedPersonRankTypePersianName;
    private Integer encouragedPersonRankTypeCivilianCode;
    private Integer encouragementStatus;
    private Integer encouragementAmountType;
    private Integer encouragementStatusNot;
    private String encouragementDescription;
    private UUID encouragementReasonTypeId;
    private LocalDate encouragementAppliedDate;
    private LocalDate encouragementSentDraftDate;
    private LocalDate encouragementCreatedAtTo;
    private LocalDate encouragementCreatedAtFrom;
    private LocalDate encouragementAppliedAtTo;
    private LocalDate encouragementAppliedAtFrom;
    private LocalDate encouragementCreatedAt;
    private Integer encouragementDraft;
//    @JsonIgnore
//    private LocalDate fromDate;
//    @JsonIgnore
//    private LocalDateTime toDate;
    private LocalDate createdAt;


}
