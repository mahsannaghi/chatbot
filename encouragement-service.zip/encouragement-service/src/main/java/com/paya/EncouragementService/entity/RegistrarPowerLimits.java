package com.paya.EncouragementService.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "tbl_registrar_power_limits")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegistrarPowerLimits {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "registrar_power_limits_id", nullable = false, columnDefinition = "uniqueidentifier")
    private UUID id;

    @Column(name = "registrar_power_limits_encouragement_type_id", nullable = false, columnDefinition = "uniqueidentifier")
    private UUID encouragementTypeId;

    @Column(name = "registrar_power_limits_rank_type_code")
    private Integer rankTypeCode;

    @Column(name = "registrar_power_limits_job_position_code")
    private Integer jobPositionCode;

    @Column(name = "registrar_power_limits_grade_id" )
    private UUID gradeId;

    @Column(name = "registrar_power_limits_job_position_id")
    private UUID jobPositionId;

    @Column(name = "registrar_power_limits_max_amount")
    private BigDecimal maxAmount;

    @Column(name = "registrar_power_limits_max_duration")
    private Integer maxDuration;

    @Column(name = "registrar_power_limits_duration_type")
    private Integer durationType;

    @Column(name = "registrar_power_limits_create_date")
    @CreationTimestamp
    private LocalDateTime createDate;


}


