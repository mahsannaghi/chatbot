package com.paya.EncouragementService.controller;


import com.paya.EncouragementService.dto.CustomMessage;
import com.paya.EncouragementService.dto.EncouragementReasonDTO;
import com.paya.EncouragementService.entity.EncouragementReason;
import com.paya.EncouragementService.service.EncouragementReasonService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.UUID;

@RestController
@RequestMapping("/api/encouragement-reasons")
@RequiredArgsConstructor
@PreAuthorize("hasAnyRole('Manager')")
public class EncouragementReasonController {

    private final EncouragementReasonService reasonService;

    @GetMapping("/filter")
    public Page<EncouragementReason> filter(
            @RequestParam(required = false) String encouragementReasonTitle,
            @RequestParam(required = false) Boolean active,
            Pageable pageable) {
        return reasonService.filter(encouragementReasonTitle, active, pageable);
    }


    @PostMapping
    public ResponseEntity<EncouragementReason> create(@RequestBody EncouragementReasonDTO dto) {
        return ResponseEntity.ok(reasonService.create(dto));
    }

    @PatchMapping("/{id}")
    public ResponseEntity<EncouragementReason> update(@PathVariable UUID id, @RequestBody EncouragementReasonDTO dto) {
        return ResponseEntity.ok(reasonService.update(id, dto));
    }

    /*@DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable UUID id) {
        reasonService.delete(id);
        return ResponseEntity.noContent().build();
    }*/

    @DeleteMapping("/{id}")
    public ResponseEntity<CustomMessage> delete(@PathVariable UUID id)  {
            return ResponseEntity.ok().body(reasonService.delete(id));
    }
}