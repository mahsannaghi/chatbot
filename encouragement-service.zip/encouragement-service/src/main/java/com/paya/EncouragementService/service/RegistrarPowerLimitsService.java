package com.paya.EncouragementService.service;

import com.paya.EncouragementService.Specification.RegistrarPowerLimitsSpecification;
import com.paya.EncouragementService.dto.*;
import com.paya.EncouragementService.entity.EncouragementType;
import com.paya.EncouragementService.entity.RegistrarPowerLimits;
import com.paya.EncouragementService.enumeration.JobPositionEnum;
import com.paya.EncouragementService.enumeration.RankTypeEnum;
import com.paya.EncouragementService.repository.EncouragementTypeRepository;
import com.paya.EncouragementService.repository.RankLevelDataFeignClient;
import com.paya.EncouragementService.repository.RegistrarPowerLimitsRepository;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import paya.net.exceptionhandler.Exception.GeneralException;

import java.math.BigDecimal;
import java.util.*;

@Service
@AllArgsConstructor
@Slf4j
public class RegistrarPowerLimitsService {
    private final RegistrarPowerLimitsRepository repository;
    private final EncouragementTypeRepository encouragementTypeRepository;
    private final RankLevelDataFeignClient rankLevelDataFeignClient;


    public List<RegistrarPowerLimitsDTO> getRegistrarPowerLimitsWithExternalData(RegistrarPowerLimitsRequestDTO requestDTO) {
//        Page<RegistrarPowerLimits> registrarPowerLimitsList = null;
//        List<RegistrarPowerLimits> registrarPowerLimitsList1 = null;
//        List<RegistrarPowerLimits> registrarPowerLimitsList2 = null;
//        List<RegistrarPowerLimits> registrarPowerLimitsList3 = null;
//        List<RegistrarPowerLimits> registrarPowerLimitsList4 = null;
//        if (jobPositionCode != null)
//            registrarPowerLimitsList1= repository.findByJobPositionCode(jobPositionCode);
//        if (rankTypeCode != null)
//            registrarPowerLimitsList2= repository.findByRankTypeCode(rankTypeCode);
//        if (rankTypeCivilianCode != null)
//            registrarPowerLimitsList3= repository.findByRankTypeCode(rankTypeCivilianCode - 11);
//        if (typeTitle != null) {
//            Optional<EncouragementType> typeOptional = encouragementTypeRepository.findByEncouragementTypeTitle(typeTitle);
//            if (typeOptional.isPresent()) {
//                EncouragementType encouragementType = typeOptional.get();
//                registrarPowerLimitsList4= repository.findByEncouragementTypeId(encouragementType.getEncouragementTypeId());
//            }
//        }
//        List<List<RegistrarPowerLimits>> nonEmptyListList = Stream.of(registrarPowerLimitsList1, registrarPowerLimitsList2, registrarPowerLimitsList3, registrarPowerLimitsList4)
//                .filter(list -> !list.isEmpty()).toList();
//        List<List<RegistrarPowerLimits>> listList = Stream.of(registrarPowerLimitsList1, registrarPowerLimitsList2, registrarPowerLimitsList3, registrarPowerLimitsList4)
//                .filter(list -> !list.isEmpty()).filter(list2 -> list2.retainAll(nonEmptyListList)).toList();
//        if (rankTypeCode == null & rankTypeCivilianCode == null & jobPositionCode == null & !(StringUtils.isNotBlank(typeTitle)))
//            registrarPowerLimitsList = repository.findAll();
        Pageable pageable =
                PageRequest.of(requestDTO.getPageNumber() != null? requestDTO.getPageNumber(): 0,
                        requestDTO.getPageSize() != null ? requestDTO.getPageSize() : 9000);
        Page<RegistrarPowerLimits> registrarPowerLimitsList = repository.findAll(
                RegistrarPowerLimitsSpecification.filterByCriteria(requestDTO),
                pageable
        );
        Map<String, RegistrarPowerLimitsDTO> groupedResults = new LinkedHashMap<>();
        for (RegistrarPowerLimits registrarPowerLimits : registrarPowerLimitsList) {
            UUID encouragementTypeIdFromDb = registrarPowerLimits.getEncouragementTypeId();
            String key = registrarPowerLimits.getJobPositionCode() + "-" + registrarPowerLimits.getRankTypeCode();
            RegistrarPowerLimitsDTO registrarPowerLimitsDTO = groupedResults.get(key);
            if (registrarPowerLimitsDTO == null) {
                registrarPowerLimitsDTO = new RegistrarPowerLimitsDTO();
                registrarPowerLimitsDTO.setId(registrarPowerLimits.getId());
                registrarPowerLimitsDTO.setJobPositionCode(registrarPowerLimits.getJobPositionCode());
                registrarPowerLimitsDTO.setJobPositionPersianName(JobPositionEnum.fromCode(registrarPowerLimits.getJobPositionCode()).getPersianName());
                registrarPowerLimitsDTO.setRankTypeCode(registrarPowerLimits.getRankTypeCode());
                registrarPowerLimitsDTO.setRankTypePersianName(RankTypeEnum.fromRankCode(registrarPowerLimits.getRankTypeCode()).getPersianName());
                registrarPowerLimitsDTO.setRankTypeCivilian(registrarPowerLimits.getRankTypeCode() + 11);
                registrarPowerLimitsDTO.setTypes(new ArrayList<>());
                groupedResults.put(key, registrarPowerLimitsDTO);
            }
            String typeTitleFromDb = encouragementTypeRepository.findById(encouragementTypeIdFromDb)
                    .map(EncouragementType::getEncouragementTypeTitle)
                    .orElse("Unknown Type");

            PowerTypesDTO powerTypesDTO = new PowerTypesDTO();

            powerTypesDTO.setTypeId(encouragementTypeIdFromDb);
            powerTypesDTO.setTypeTitle(typeTitleFromDb);
            powerTypesDTO.setMaxAmount(registrarPowerLimits.getMaxAmount() == null ? BigDecimal.valueOf(0) : registrarPowerLimits.getMaxAmount());
            powerTypesDTO.setMaxDuration(registrarPowerLimits.getMaxDuration() == null ? 0 : registrarPowerLimits.getMaxDuration());
            powerTypesDTO.setDurationType(registrarPowerLimits.getDurationType());
            registrarPowerLimitsDTO.getTypes().add(powerTypesDTO);
//            if (rank != null) {
//                ResponseEntity<List<RankLevelDataDTO>> gradeResponse = rankLevelDataFeignClient.getRankLevelData(
//                        rank.toString(), null);
//                if (gradeResponse != null && gradeResponse.getBody() != null && !gradeResponse.getBody().isEmpty()) {
//                    RankLevelDataDTO rankLevelData = findRankLevelDataByGradeId(gradeResponse.getBody(), rank);
//                    GradeDTO gradeDTO = new GradeDTO();
//                        gradeDTO.setGradeid(gradeIdFromDb);
//                    gradeDTO.setRankTypeCode(registrarPowerLimits.getRankTypeCode());
//                        gradeDTO.setRankLevelDataDegree(rankLevelData.getRankLevelDataDegree());
//                        gradeDTO.setRankLevelDataFieldNumber(rankLevelData.getRankLevelDataFieldNumber());
//                        gradeDTO.setRankLevelDataJobLevel(rankLevelData.getRankLevelDataJobLevel());
//                        gradeDTO.setRankLevelDataRank(rankLevelData.getRankLevelDataRank());
//                }
//            }
//            if (position != null) {
//                ResponseEntity<List<RankLevelDataDTO>> positionResponse = rankLevelDataFeignClient.getRankLevelData(
//                        null, jobPositionId.toString());
//                if (positionResponse != null && positionResponse.getBody() != null && !positionResponse.getBody().isEmpty()) {
//                    RankLevelDataDTO rankLevelData = findRankLevelDataByPositionId(positionResponse.getBody(), jobPositionId);
//                if (rank != null) {
//                    PositionDTO positionDTO = new PositionDTO();
//                        positionDTO.setPositionid(jobPosition);
//                        positionDTO.setRankLevelDataDegree(rankLevelData.getRankLevelDataDegree());
//                        positionDTO.setRankLevelDataFieldNumber(rankLevelData.getRankLevelDataFieldNumber());
//                        positionDTO.setRankLevelDataJobLevel(rankLevelData.getRankLevelDataJobLevel());
//                        positionDTO.setRankLevelDataRank(rankLevelData.getRankLevelDataRank());
//                    positionDTO.setPositionTypeCode(registrarPowerLimits.getJobPositionCode());
//                }
//            }
//        }
//        }
//        /** @ّFilters */
//        if (position != null) {
//            groupedResults = groupedResults.entrySet()
//                    .stream()
//                    .filter(map -> map.getValue().getPosition().getRankLevelDataJobLevel().equals(position))
//                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
//
//        }
//        if (rank != null) {
//            groupedResults = groupedResults.entrySet()
//                    .stream()
//                    .filter(map -> map.getValue().getRankTypeCode().equals(rank))
//                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
//
//        }
//        if (degree != null) {
//            groupedResults = groupedResults.entrySet()
//                    .stream()
//                    .filter(map -> map.getValue()
//                            .getGrade()
//                            .getRankLevelDataDegree()
//                            .contains(degree))
//                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
//
//        }
//        if (typeTitleEntry != null) {
//            groupedResults = groupedResults.entrySet().stream()
//                    .filter(map -> map.getValue()
//                            .getTypes()
//                            .stream()
//                            .anyMatch(type -> type.getTypeTitle().contains(typeTitleEntry)))
//                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
//        }
        }
        return new ArrayList<>(groupedResults.values());
    }


//    private RankLevelDataDTO findRankLevelDataByGradeId(List<RankLevelDataDTO> rankLevelDataList, UUID gradeId) {
//        for (RankLevelDataDTO rankLevelData : rankLevelDataList) {
//            if (rankLevelData.getJobGroupLevel().equals(gradeId)) {
//                return rankLevelData;
//            }
//        }
//        return null;
//    }
//
//    private RankLevelDataDTO findRankLevelDataByPositionId(List<RankLevelDataDTO> rankLevelDataList, UUID positionId) {
//        for (RankLevelDataDTO rankLevelData : rankLevelDataList) {
//            if (rankLevelData.getJobGroupLevel().equals(positionId)) {
//                return rankLevelData;
//            }
//        }
//        return null;
//    }


    @Transactional
    public void saveRegistrarPowerLimits(RegistrarPowerLimitsRequestDTO requestDTO) {
        Integer rankCode = requestDTO.getRankTypeCode();
        Integer jobPosition = requestDTO.getJobPositionCode();
        if (requestDTO.getTypesToAddOrUpdate() != null) {
            for (PowerTypeDTO type : requestDTO.getTypesToAddOrUpdate()) {
                Optional<RegistrarPowerLimits> existingLimit = repository
                        .findByRankTypeCodeAndJobPositionCodeAndEncouragementTypeId(
                                rankCode, jobPosition, type.getTypeId()
                        );
                if (existingLimit.isPresent()) {
                    RegistrarPowerLimits limit = existingLimit.get();
                    limit.setMaxAmount(type.getMaxAmount());
                    limit.setMaxDuration(type.getMaxDuration());
                    limit.setRankTypeCode(rankCode);
                    limit.setJobPositionCode(jobPosition);
                    limit.setDurationType(type.getDurationType());
                    repository.save(limit);
                } else {
                    RegistrarPowerLimits newLimit = new RegistrarPowerLimits();
                    newLimit.setRankTypeCode(rankCode);
                    newLimit.setJobPositionCode(jobPosition);
                    newLimit.setEncouragementTypeId(type.getTypeId());
                    newLimit.setMaxAmount(type.getMaxAmount());
                    newLimit.setMaxDuration(type.getMaxDuration());
                    newLimit.setDurationType(type.getDurationType());
                    repository.save(newLimit);
                }
            }
        }

        if (requestDTO.getDeleteTheseTypes() != null) {
            for (UUID typeId : requestDTO.getDeleteTheseTypes()) {
                Optional<RegistrarPowerLimits> limitToDelete = repository
                        .findByRankTypeCodeAndJobPositionCodeAndEncouragementTypeId(
                                rankCode, jobPosition, typeId
                        );
                if (limitToDelete.isPresent()) {
                    repository.delete(limitToDelete.get());
                } else {
                    log.warn("Type with ID {} does not exist for this gradeId and positionId, skipping deletion.", typeId);
                }
            }
        }
    }

    public Boolean existsByRankTypeCodeAndPositionCode(Integer rankTypeCode, Integer positionCode, UUID typeId) {
        if (rankTypeCode != null && positionCode != null) {
            return repository.existsByRankTypeCodeAndJobPositionCodeAndEncouragementTypeId(rankTypeCode, positionCode, typeId);
        } else throw new GeneralException("پارامتر ورودی صحیح نمی باشد .");
    }


    public RegistrarPowerLimits findByRankTypeCodeAndPositionCodeAndTypeId(Integer grade, Integer jobPosition, UUID typeId) {
        if (grade != null && jobPosition != null) {
            Optional<RegistrarPowerLimits> optional = repository.findByRankTypeCodeAndJobPositionCodeAndEncouragementTypeId(grade, jobPosition, typeId);
            return optional.orElse(null);
        } else throw new GeneralException("پارامتر ورودی صحیح نمی باشد .");
    }


}
