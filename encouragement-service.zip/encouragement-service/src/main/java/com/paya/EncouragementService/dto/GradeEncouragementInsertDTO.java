package com.paya.EncouragementService.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.util.UUID;

@Data
public class GradeEncouragementInsertDTO {
    @JsonIgnore
    private UUID gradeEncouragementId;
    private Integer gradeEncouragementNewGrade;
    @JsonIgnore
    private UUID gradeEncouragementRegistrarPersonnelId;
    private UUID gradeEncouragementRelatedPersonnelId;

}
