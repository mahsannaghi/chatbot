package com.paya.EncouragementService.service;

import com.paya.EncouragementService.Specification.EncouragementReviewSpecification;
import com.paya.EncouragementService.dto.EncouragementReviewDTO;
import com.paya.EncouragementService.dto.EncouragementReviewSearchDTO;
import com.paya.EncouragementService.entity.EncouragementReview;
import com.paya.EncouragementService.enumeration.ReviewResultEnum;
import com.paya.EncouragementService.enumeration.ReviewTypeEnum;
import com.paya.EncouragementService.repository.EncouragementRepository;
import com.paya.EncouragementService.repository.EncouragementReviewRepository;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import paya.net.exceptionhandler.Exception.GeneralException;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class EncouragementReviewService {
    private final EncouragementReviewRepository repository;
    private final EncouragementRepository encouragementRepository;


//    public List<EncouragementReviewDTO> getAllEncouragementReviews(
//            UUID encouragementReviewEncouragementId,
//            UUID encouragementReviewRegistrarPersonnelId,
//            UUID encouragementReviewPayingAuthorityId,
//            UUID encouragementReviewEncouragementTypeId,
//            Integer encouragementReviewResult,
//            String encouragementReviewDescription,
//            Date encouragementReviewCreatedAt,
//            Double encouragementReviewAmount,
//            Integer encouragementReviewAmountType,
//            Integer encouragementReviewPercentage,
//            Integer encouragementReviewType,
//            Date encouragementReviewUpdatedAt,
//            Date encouragementReviewApprovalDate,
//            String encouragementReviewOrganizationId) {
//
//        List<EncouragementReview> resultList = getEncouragementReviewsWithSpecification(encouragementReviewEncouragementId, encouragementReviewRegistrarPersonnelId, encouragementReviewPayingAuthorityId, encouragementReviewEncouragementTypeId, encouragementReviewResult, encouragementReviewDescription, encouragementReviewCreatedAt, encouragementReviewAmount, encouragementReviewAmountType, encouragementReviewPercentage, encouragementReviewType, encouragementReviewUpdatedAt, encouragementReviewApprovalDate, encouragementReviewOrganizationId);
//        // تبدیل نتایج به DTO ها
//        return resultList.stream()
//                .map(encouragementReview -> {
//                    UUID encouragementId = encouragementReview.getEncouragementReviewEncouragementId();
//                    Optional<Encouragement> optional = encouragementRepository.findByEncouragementId(encouragementId);
//                    if (optional.isPresent()) {
//                        Encouragement encouragement = optional.get();
//                    }
//                    return convertToDTO(encouragementReview);
//                })
//                .collect(Collectors.toList());
//    }

    public Page<EncouragementReview> getEncouragementReviewsWithSpecification(EncouragementReviewSearchDTO dto, PageRequest pageRequest) {
        return repository.findAll(
                EncouragementReviewSpecification.filterByCriteria(dto), pageRequest
        );
    }

    public EncouragementReviewDTO createEncouragementReview(EncouragementReviewDTO dto) {
        if (dto.getEncouragementReviewEncouragementId() == null) {
            throw new GeneralException("EncouragementReviewEncouragementId must not be null");
        }

        EncouragementReview entity = convertToEntity(dto);
        entity.setEncouragementReviewId(UUID.randomUUID());
        repository.save(entity);
        return convertToDTO(entity);
    }


    @Transactional
    public EncouragementReview add(EncouragementReview encouragement) {
        return repository.save(encouragement);
    }

    @Transactional
    public List<EncouragementReview> add(List<EncouragementReview> encouragementReviewList) {
        return repository.saveAll(encouragementReviewList);
    }

    @Transactional
    public void changeEncouragementReviewStatus(EncouragementReview encouragementReview, Integer result) {
        encouragementReview.setEncouragementReviewResult(result);
        encouragementReview.setEncouragementReviewAppliedDate(LocalDate.now());
        repository.save(encouragementReview);
    }


//    public EncouragementReviewDTO updateEncouragementReview(UUID id, EncouragementReviewDTO dto) {
//        EncouragementReview entity = repository.findById(id)
//                .orElseThrow(() -> new GeneralException("EncouragementReview not found"));
//        entity = convertToEntity(dto, entity);
//        entity.setEncouragementReviewId(id);
//        repository.save(entity);
//        return convertToDTO(entity);
//    }


    public void deleteEncouragementReview(UUID id) {
        repository.deleteById(id);
    }

    public List<EncouragementReviewDTO> getAllForVedja() {
        List<EncouragementReview> reviewList = repository.findAllByEncouragementReviewTypeAndEncouragementReviewEncouragementId(ReviewTypeEnum.VEDJA_COMMISSION.getCode(), null);
        return this.convertToDTO(reviewList);
    }

    public List<EncouragementReview> getAllCommissionReviewsForThisEncouragement(UUID encouragementId) {
        return repository.findAllByEncouragementReviewTypeAndEncouragementReviewEncouragementId(ReviewTypeEnum.ORDINARY_COMMISSION.getCode(), encouragementId);
//        return this.convertToDTO(reviewList);
    }


    private EncouragementReview convertToEntity(EncouragementReviewDTO dto) {
        EncouragementReview entity = new EncouragementReview();
        entity.setEncouragementReviewEncouragementId(dto.getEncouragementReviewEncouragementId());
        entity.setEncouragementReviewRegistrarOrganizationId(dto.getEncouragementReviewRegistrarOrganizationId());
        entity.setEncouragementReviewPayingAuthorityId(dto.getEncouragementReviewPayingAuthorityId());
        entity.setEncouragementReviewEncouragementTypeId(dto.getEncouragementReviewEncouragementTypeId());
        entity.setEncouragementReviewResult(dto.getEncouragementReviewResult());
        entity.setEncouragementReviewDescription(dto.getEncouragementReviewDescription());
//        entity.setEncouragementReviewCreatedAt(dto.getEncouragementReviewCreatedAt());
        entity.setEncouragementReviewAmount(dto.getEncouragementReviewAmount());
        entity.setEncouragementReviewAmountType(dto.getEncouragementReviewAmountType());
        entity.setEncouragementReviewPercentage(dto.getEncouragementReviewPercentage());
        entity.setEncouragementReviewType(dto.getEncouragementReviewType());
//        entity.setEncouragementReviewUpdatedAt(dto.getEncouragementReviewUpdatedAt());
//        entity.setEncouragementReviewApprovalDate(dto.getEncouragementReviewApprovalDate());
        entity.setEncouragementReviewRegistrarOrganizationId(dto.getEncouragementReviewOrganizationId());
        return entity;
    }


//    private EncouragementReview convertToEntity(EncouragementReviewDTO dto, EncouragementReview entity) {
//        entity.setEncouragementReviewEncouragementId(dto.getEncouragementReviewEncouragementId());
//        entity.setEncouragementReviewRegistrarOrganizationId(dto.getEncouragementReviewRegistrarPersonnelId());
//        entity.setEncouragementReviewPayingAuthorityId(dto.getEncouragementReviewPayingAuthorityId());
//        entity.setEncouragementReviewEncouragementTypeId(dto.getEncouragementReviewEncouragementTypeId());
//        entity.setEncouragementReviewResult(dto.getEncouragementReviewResult());
//        entity.setEncouragementReviewDescription(dto.getEncouragementReviewDescription());
////        entity.setEncouragementReviewCreatedAt(dto.getEncouragementReviewCreatedAt());
//        entity.setEncouragementReviewAmount(dto.getEncouragementReviewAmount());
//        entity.setEncouragementReviewAmountType(dto.getEncouragementReviewAmountType());
//        entity.setEncouragementReviewPercentage(dto.getEncouragementReviewPercentage());
//        entity.setEncouragementReviewType(dto.getEncouragementReviewType());
////        entity.setEncouragementReviewUpdatedAt(dto.getEncouragementReviewUpdatedAt());
//        entity.setEncouragementReviewAppliedDate(dto.getEncouragementReviewApprovalDate());
//        entity.setEncouragementReviewRegistrarOrganizationId(dto.getEncouragementReviewOrganizationId());
//        return entity;
//    }

    public EncouragementReviewDTO convertToDTO(EncouragementReview entity) {
        return new EncouragementReviewDTO(
                entity.getEncouragementReviewId(),
                entity.getEncouragementReviewRegistrarOrganizationId(),
                entity.getEncouragementReviewPayingAuthorityId(),
                entity.getEncouragementReviewEncouragementTypeId(),
                entity.getEncouragementReviewResult(),
                entity.getEncouragementReviewDescription(),
//                entity.getEncouragementReviewCreatedAt(),
                entity.getEncouragementReviewAmount(),
                entity.getEncouragementReviewAmountType(),
                entity.getEncouragementReviewPercentage(),
                entity.getEncouragementReviewType(),
//                entity.getEncouragementReviewUpdatedAt(),
                entity.getEncouragementReviewSentDraftDate(),
                entity.getEncouragementReviewRegistrarOrganizationId(),
                entity.getEncouragementReviewAppliedDate(),
                entity.getEncouragementReviewDraft() != null ? entity.getEncouragementReviewDraft().getCode() : 0);
    }

    private List<EncouragementReviewDTO> convertToDTO(List<EncouragementReview> entityList) {
        return entityList.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }


    public EncouragementReview findById(UUID encouragementReviewId) {
        return repository.findById(encouragementReviewId).orElseThrow(() -> new GeneralException("بررسی تشویق مورد نظر یافت نشد . "));
    }

    public EncouragementReview getReviewOfThisRegistrarThisEncouragement(String encouragementRegistrarOrganizationId, UUID encouragementId) {
        Optional<EncouragementReview> optional = repository.findByEncouragementReviewRegistrarOrganizationIdAndEncouragementReviewEncouragementIdAndEncouragementReviewResult(encouragementRegistrarOrganizationId, encouragementId, ReviewResultEnum.UNDER_REVIEW.getCode());
        return optional.orElse(null);
    }
}
