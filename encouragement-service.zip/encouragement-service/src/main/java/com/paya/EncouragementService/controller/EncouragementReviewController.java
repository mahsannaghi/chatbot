package com.paya.EncouragementService.controller;

import com.paya.EncouragementService.dto.EncouragementReviewDTO;
import com.paya.EncouragementService.dto.EncouragementReviewSearchDTO;
import com.paya.EncouragementService.dto.EncouragementReviewUpdateDTO;
import com.paya.EncouragementService.service.EncouragementReviewService;
import com.paya.EncouragementService.service.EncouragementService;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/encouragement-review")
@PreAuthorize("hasAnyRole('Manager')")
@AllArgsConstructor
public class EncouragementReviewController {


    private final EncouragementReviewService encouragementReviewService;
    private final EncouragementService encouragementService;


    @PostMapping("search")
    public ResponseEntity<Page<EncouragementReviewDTO>> getAllEncouragementReviews(
            EncouragementReviewSearchDTO dto,
            @RequestParam(required = false, defaultValue = "100") Integer pageSize,
            @RequestParam(required = false, defaultValue = "0") Integer pageNumber) throws Exception {
        PageRequest pageRequest = PageRequest.of(pageNumber, pageSize);
        return ResponseEntity.ok().body(encouragementService.getAllEncouragementReviews(dto, pageRequest));
    }


    @PostMapping
    public ResponseEntity<EncouragementReviewDTO> createEncouragementReview(@RequestBody EncouragementReviewDTO encouragementReviewDTO) {
        EncouragementReviewDTO createdReview = encouragementReviewService.createEncouragementReview(encouragementReviewDTO);
        return new ResponseEntity<>(createdReview, HttpStatus.CREATED);
    }


    //    @PutMapping("/{id}")
//    public ResponseEntity<EncouragementReviewDTO> updateEncouragementReview(
//            @PathVariable UUID id,
//            @RequestBody EncouragementReviewDTO encouragementReviewDTO) {
//
//        EncouragementReviewDTO updatedReview = encouragementReviewService.updateEncouragementReview(id, encouragementReviewDTO);
//        return ResponseEntity.ok(updatedReview);
//    }
    @PatchMapping
    public ResponseEntity<EncouragementReviewDTO> updateEncouragementReview(
            @RequestBody EncouragementReviewUpdateDTO encouragementReviewDTO) throws Exception {
        EncouragementReviewDTO updatedReview = encouragementService.updateEncouragementReview(encouragementReviewDTO);
        return ResponseEntity.ok(updatedReview);
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEncouragementReview(@PathVariable UUID id) {
        encouragementReviewService.deleteEncouragementReview(id);
        return ResponseEntity.noContent().build();
    }

}
