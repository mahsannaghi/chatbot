package com.paya.EncouragementService.enumeration;


import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum EncouragementResultEnum {
    UNDER_REVIEW(0, "UNDER_REVIEW", "درحال بررسی"),
    APPROVED(1, "APPROVED", "تایید شده"),
    REJECTED(2, "REJECTED", "رد شده"),
    SENT_FOR_CORRECTION(3, "SENT_FOR_CORRECTION", "ارسال برای اصلاح"),
    DRAFT(4, "DRAFT", "پیش نویس"),
    NEED_FOR_ACCEPT(5, "NEED_FOR_ACCEPT", "نیازمند تایید");

    private final int code;
    private final String title;
    private final String Description;

    public static EncouragementResultEnum fromCode(int code) {
        for (EncouragementResultEnum draft : EncouragementResultEnum.values()) {
            if (draft.getCode() == code) {
                return draft;
            }
        }
        throw new IllegalArgumentException("Invalid code: " + code);
    }
}
