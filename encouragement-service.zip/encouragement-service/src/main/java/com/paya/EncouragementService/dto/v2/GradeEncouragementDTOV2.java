package com.paya.EncouragementService.dto.v2;

import com.paya.EncouragementService.dto.PersonnelDTO;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
public class GradeEncouragementDTOV2 {
    private UUID gradeEncouragementId;
    private LocalDateTime gradeEncouragementCreatedAt;
    private Integer gradeEncouragementNewGrade;
    private String gradeEncouragementNewGradeTitle;
    private UUID gradeEncouragementRelatedPersonnelId;
    private Integer seniorityAmount;
    private PersonnelDTO personnel;
    private List<AttachmentGetDTO> files;

    public GradeEncouragementDTOV2(UUID gradeEncouragementId, LocalDateTime gradeEncouragementCreatedAt, Integer gradeEncouragementNewGrade, UUID gradeEncouragementRelatedPersonnelId) {
        this.gradeEncouragementId = gradeEncouragementId;
        this.gradeEncouragementCreatedAt = gradeEncouragementCreatedAt;
        this.gradeEncouragementNewGrade = gradeEncouragementNewGrade;
        this.gradeEncouragementRelatedPersonnelId = gradeEncouragementRelatedPersonnelId;
    }
}
