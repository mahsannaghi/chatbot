package com.paya.EncouragementService.controller;


import com.paya.EncouragementService.entity.TblUser;
import com.paya.EncouragementService.service.AuthService;
import feign.FeignException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import paya.net.exceptionhandler.Exception.GeneralException;

@RestController
@RequestMapping(value = {"get-current-user" , "get-current-user/"})
@Slf4j
@PreAuthorize("hasAnyRole('Assistant' , 'Personnel' ,'ExecutiveManager' , 'WelfareServiceManager' ,'WelfareServiceSpecialist')")
public class CurrentUserController {
    private final AuthService authService;

    public CurrentUserController(AuthService authService) {
        this.authService = authService;
    }

    @GetMapping
    public ResponseEntity<TblUser> getCurrentUser() throws Exception {
        try {
            log.info( "Authorities : " + SecurityContextHolder.getContext().getAuthentication().getAuthorities());
            log.info( "Principal : " + SecurityContextHolder.getContext().getAuthentication().getPrincipal());
            log.info( "Name : " + SecurityContextHolder.getContext().getAuthentication().getName());
        return ResponseEntity.ok().body(authService.getIsLoginUser());
        } catch (FeignException ex){
            throw new GeneralException("احراز هویت منقضی شده است. لطفاً مجدداً وارد شوید.");
        }
    }
}
