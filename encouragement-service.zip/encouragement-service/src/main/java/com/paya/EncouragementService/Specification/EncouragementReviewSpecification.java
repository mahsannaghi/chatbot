package com.paya.EncouragementService.Specification;

import com.paya.EncouragementService.dto.EncouragementReviewSearchDTO;
import com.paya.EncouragementService.entity.*;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import org.springframework.data.jpa.domain.Specification;

import java.util.UUID;

public class EncouragementReviewSpecification {

    public static Specification<EncouragementReview> filterByCriteria(
            EncouragementReviewSearchDTO dto) {

        return (root, query, criteriaBuilder) -> {
            Specification<EncouragementReview> spec = Specification.where(null);

            if (dto.getEncouragementReviewEncouragementId() != null) {
                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.equal(root1.get("encouragementReviewEncouragementId"), dto.getEncouragementReviewEncouragementId()));
            }
            if (dto.getEncouragementReviewRegistrarPersonnelId() != null) {
                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.equal(root1.get("encouragementReviewRegistrarPersonnelId"), dto.getEncouragementReviewRegistrarPersonnelId()));
            }
            if (dto.getEncouragementReviewRegistrarPersonnelOrganizationId() != null) {
                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.equal(root1.get("encouragementReviewRegistrarOrganizationId"), dto.getEncouragementReviewRegistrarPersonnelOrganizationId()));
            }
            if (dto.getEncouragementReviewPayingAuthorityId() != null) {
                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.equal(root1.get("encouragementReviewPayingAuthorityId"), dto.getEncouragementReviewPayingAuthorityId()));
            }
            if (dto.getEncouragementReviewEncouragementTypeId() != null) {
                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.equal(root1.get("encouragementReviewEncouragementTypeId"), dto.getEncouragementReviewEncouragementTypeId()));
            }
            if (dto.getEncouragementReviewResult() != null) {
                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.equal(root1.get("encouragementReviewResult"), dto.getEncouragementReviewResult()));
            }
            if (dto.getEncouragementReviewDescription() != null && !dto.getEncouragementReviewDescription().isEmpty()) {
                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.like(root1.get("encouragementReviewDescription"), "%" + dto.getEncouragementReviewDescription() + "%"));
            }
            if (dto.getEncouragementReviewCreatedAt() != null) {
                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.equal(root1.get("encouragementReviewCreatedAt"), dto.getEncouragementReviewCreatedAt()));
            }
            if (dto.getEncouragementReviewAmount() != null) {
                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.equal(root1.get("encouragementReviewAmount"), dto.getEncouragementReviewAmount()));
            }
            if (dto.getEncouragementReviewAmountType() != null) {
                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.equal(root1.get("encouragementReviewAmountType"), dto.getEncouragementReviewAmountType()));
            }
            if (dto.getEncouragementReviewPercentage() != null) {
                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.equal(root1.get("encouragementReviewPercentage"), dto.getEncouragementReviewPercentage()));
            }
            if (dto.getEncouragementReviewType() != null) {
                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.equal(root1.get("encouragementReviewType"), dto.getEncouragementReviewType()));
            }
            if (dto.getEncouragementReviewUpdatedAt() != null) {
                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.equal(root1.get("encouragementReviewUpdatedAt"), dto.getEncouragementReviewUpdatedAt()));
            }
            if (dto.getEncouragementReviewApprovalDate() != null) {
                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.equal(root1.get("encouragementReviewApprovalDate"), dto.getEncouragementReviewApprovalDate()));
            }
            if (dto.getEncouragementReviewSentDraftDateFrom() != null) {
                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.greaterThanOrEqualTo(root1.get("encouragementReviewSentDraftDate"), dto.getEncouragementReviewSentDraftDateFrom()));
            }
            if (dto.getEncouragementReviewSentDraftDateTo() != null) {
                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.lessThanOrEqualTo(root1.get("encouragementReviewSentDraftDate"), dto.getEncouragementReviewSentDraftDateTo()));
            }
            if (dto.getEncouragementReviewRegistrarOrgIdNotEncouragementRegistrarOrgId() != null) {
//                Subquery<String> subquery = query.subquery(String.class);
//                Root<Encouragement> encouragementRoot = subquery.from(Encouragement.class);
//                subquery.select(encouragementRoot.get("encouragementRegistrarOrganizationId"))
//                        .where(criteriaBuilder.notEqual(encouragementRoot.get("encouragementRegistrarOrganizationId"), dto.getEncouragementReviewRegistrarOrgIdNotEncouragementRegistrarOrgId()));
//
//                spec= spec.and((root1, query1, criteriaBuilder1) -> criteriaBuilder1.not(root1.get("encouragementReviewRegistrarOrganizationId").in(subquery)));
//                spec = spec.and((root1, query1, criteriaBuilder1) -> criteriaBuilder1.equal(root1.get("encouragementReviewRegistrarOrganizationId"), dto.getEncouragementReviewRegistrarOrgIdNotEncouragementRegistrarOrgId()));

                Subquery<UUID> subquery = query.subquery(UUID.class);
                Root<Encouragement> encouragementRoot = subquery.from(Encouragement.class);
                subquery.select(encouragementRoot.get("encouragementId"))
                        .where(criteriaBuilder.notEqual(encouragementRoot.get("encouragementRegistrarOrganizationId"), dto.getEncouragementReviewRegistrarOrgIdNotEncouragementRegistrarOrgId()));

                spec = spec.and((root1, query1, criteriaBuilder1) -> root1.get("encouragementReviewEncouragementId").in(subquery));
                spec = spec.and((root1, query1, criteriaBuilder1) -> criteriaBuilder1.equal(root1.get("encouragementReviewRegistrarOrganizationId"), dto.getEncouragementReviewRegistrarOrgIdNotEncouragementRegistrarOrgId()));
            }
            if (dto.getEncouragementReviewEncouragedOrganizationId() != null) {
                Subquery<UUID> subquery = query.subquery(UUID.class);
                Root<Encouragement> encouragementRoot = subquery.from(Encouragement.class);
                subquery.select(encouragementRoot.get("encouragementId"))
                        .where(criteriaBuilder.equal(encouragementRoot.get("encouragementPersonnelOrganizationId"), dto.getEncouragementReviewEncouragedOrganizationId()));

                spec = spec.and((root1, query1, criteriaBuilder1) -> root1.get("encouragementReviewEncouragementId").in(subquery));
            }
            if (dto.getEncouragementReviewEncouragedRegistrarOrganizationId() != null) {

                Subquery<UUID> subquery = query.subquery(UUID.class);
                Root<Encouragement> encouragementRoot = subquery.from(Encouragement.class);
                subquery.select(encouragementRoot.get("encouragementId"))
                        .where(criteriaBuilder.equal(encouragementRoot.get("encouragementRegistrarOrganizationId"), dto.getEncouragementReviewEncouragedRegistrarOrganizationId()));

                spec = spec.and((root1, query1, criteriaBuilder1) -> root1.get("encouragementReviewEncouragementId").in(subquery));

            }
            if (dto.getEncouragementNumber() != null) {
                Subquery<UUID> subquery = query.subquery(UUID.class);
                Root<Encouragement> encouragementRoot = subquery.from(Encouragement.class);
                subquery.select(encouragementRoot.get("encouragementId"))
                        .where(criteriaBuilder.equal(encouragementRoot.get("encouragementNumber"), dto.getEncouragementNumber()));

                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.equal(root1.get("encouragementReviewEncouragementId"), subquery));

//                return root.get("encouragementReviewRegistrarOrganizationId").in(subquery);
            }
            if (dto.getEncouragementAmount() != null) {
                Subquery<UUID> subquery = query.subquery(UUID.class);
                Root<Encouragement> encouragementRoot = subquery.from(Encouragement.class);
                subquery.select(encouragementRoot.get("encouragementId"))
                        .where(criteriaBuilder.equal(encouragementRoot.get("encouragementAmount"), dto.getEncouragementAmount()));

                spec = spec.and((root1, query1, criteriaBuilder1) ->
                        criteriaBuilder1.equal(root1.get("encouragementReviewEncouragementId"), subquery));

            }
            if (dto.getEncouragementTypeTitle() != null) {
                Subquery<UUID> typeSubquery = query.subquery(UUID.class);
                Root<EncouragementType> typeRoot = typeSubquery.from(EncouragementType.class);
                typeSubquery.select(typeRoot.get("encouragementTypeId"))
                        .where(criteriaBuilder.like(typeRoot.get("encouragementTypeTitle"), "%" + dto.getEncouragementTypeTitle() + "%"));

                Subquery<UUID> subquery1 = query.subquery(UUID.class);
                Root<EncouragementReasonType> encouragementRoot1 = subquery1.from(EncouragementReasonType.class);
                subquery1.select(encouragementRoot1.get("encouragementReasonTypeId"))
                        .where(encouragementRoot1.get("encouragementTypeId").in(typeSubquery));

                Subquery<UUID> subquery = query.subquery(UUID.class);
                Root<Encouragement> encouragementRoot = subquery.from(Encouragement.class);
                subquery.select(encouragementRoot.get("encouragementId"))
                        .where(encouragementRoot.get("encouragementReasonTypeId").in(subquery1));

                spec = spec.and((root1, query1, criteriaBuilder1) -> root1.get("encouragementReviewEncouragementId").in(subquery));

            }
            if (dto.getEncouragementReasonTitle() != null) {
                Subquery<UUID> typeSubquery = query.subquery(UUID.class);
                Root<EncouragementReason> typeRoot = typeSubquery.from(EncouragementReason.class);
                typeSubquery.select(typeRoot.get("encouragementReasonId"))
                        .where(criteriaBuilder.like(typeRoot.get("encouragementReasonTitle"), "%" + dto.getEncouragementReasonTitle() + "%"));

                Subquery<UUID> subquery1 = query.subquery(UUID.class);
                Root<EncouragementReasonType> encouragementRoot1 = subquery1.from(EncouragementReasonType.class);
                subquery1.select(encouragementRoot1.get("encouragementReasonTypeId"))
                        .where(encouragementRoot1.get("encouragementReasonId").in(typeSubquery));

                Subquery<UUID> subquery = query.subquery(UUID.class);
                Root<Encouragement> encouragementRoot = subquery.from(Encouragement.class);
                subquery.select(encouragementRoot.get("encouragementId"))
                        .where(encouragementRoot.get("encouragementReasonTypeId").in(subquery1));

                spec = spec.and((root1, query1, criteriaBuilder1) -> root1.get("encouragementReviewEncouragementId").in(subquery));

            }

            return spec.toPredicate(root, query, criteriaBuilder);
        };
    }
}
