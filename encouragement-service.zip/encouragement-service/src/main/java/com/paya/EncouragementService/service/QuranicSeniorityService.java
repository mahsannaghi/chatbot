package com.paya.EncouragementService.service;

import com.paya.EncouragementService.dto.QuranicSeniorityDTO;
import com.paya.EncouragementService.entity.QuranicSeniority;
import com.paya.EncouragementService.repository.QuranicSeniorityRepository;
import com.paya.EncouragementService.Specification.QuranicSenioritySpecification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import paya.net.exceptionhandler.Exception.GeneralException;

import java.util.Optional;
import java.util.UUID;

@Service
public class QuranicSeniorityService {

    @Autowired
    private QuranicSeniorityRepository repository;


    private static int MAX_SENIORITY = 48;


    public int getMaxSeniority() {
        return MAX_SENIORITY;
    }


    public void updateMaxSeniority(int newMaxSeniority) {
        MAX_SENIORITY = newMaxSeniority;
    }


    public QuranicSeniority createQuranicSeniority(QuranicSeniorityDTO dto) {
        if (dto.getQuranicSeniorityType() == null || dto.getQuranicSeniorityType().trim().isEmpty()) {
            throw new GeneralException("نوع نباید خالی  باشد!");
        }
        Optional<QuranicSeniority> optional = repository.findByQuranicSeniorityTypeAndQuranicSeniorityAmount(dto.getQuranicSeniorityType(), dto.getQuranicSeniorityAmount());
        if (optional.isPresent()) {
            QuranicSeniority seniority = optional.get();
            if ((seniority.getQuranicSeniorityType().equals(dto.getQuranicSeniorityType()) && seniority.getQuranicSeniorityAmount().equals(dto.getQuranicSeniorityAmount()))) {
                return createQuranicSeniorityAfterValidation(dto);
            } else
                throw new GeneralException("نوع و میزان تکراری است!");
        } else {
            return createQuranicSeniorityAfterValidation(dto);
        }
    }

    private QuranicSeniority createQuranicSeniorityAfterValidation(QuranicSeniorityDTO dto) {
        QuranicSeniority entity;
        entity = QuranicSeniority.builder()
                .quranicSeniorityType(dto.getQuranicSeniorityType())
                .quranicSeniorityAmount(dto.getQuranicSeniorityAmount())
                .quranicSeniorityMaxAmount(dto.getQuranicSeniorityMaxAmount())
                .quranicSeniorityIsActive(dto.getQuranicSeniorityIsActive() != null ? dto.getQuranicSeniorityIsActive() : true)
                .build();
        return repository.save(entity);
    }


    public QuranicSeniority updateQuranicSeniority(QuranicSeniorityDTO dto) {
        QuranicSeniority entity = repository.findById(dto.getQuranicSeniorityId())
                .orElseThrow(() -> new GeneralException("Entity with ID not found"));


        boolean isTypeSame = entity.getQuranicSeniorityType().equals(dto.getQuranicSeniorityType());
        boolean isActiveSame =
                (dto.getQuranicSeniorityIsActive() == null && entity.getQuranicSeniorityIsActive() == null) ||
                        (dto.getQuranicSeniorityIsActive() != null && dto.getQuranicSeniorityIsActive().equals(entity.getQuranicSeniorityIsActive()));
        boolean isAmountSame =
                (dto.getQuranicSeniorityAmount() == null && entity.getQuranicSeniorityAmount() == null) ||
                        (dto.getQuranicSeniorityAmount() != null && dto.getQuranicSeniorityAmount().equals(entity.getQuranicSeniorityAmount()));
        boolean isMaxAmountSame =
                (dto.getQuranicSeniorityMaxAmount() == null && entity.getQuranicSeniorityMaxAmount() == null) ||
                        (dto.getQuranicSeniorityMaxAmount() != null && dto.getQuranicSeniorityMaxAmount().equals(entity.getQuranicSeniorityMaxAmount()));


        if (isTypeSame && isActiveSame && isAmountSame && isMaxAmountSame) {
            throw new GeneralException("No changes detected");
        }


        entity.setQuranicSeniorityType(dto.getQuranicSeniorityType());
        entity.setQuranicSeniorityAmount(dto.getQuranicSeniorityAmount());
        entity.setQuranicSeniorityMaxAmount(dto.getQuranicSeniorityMaxAmount());
        entity.setQuranicSeniorityIsActive(dto.getQuranicSeniorityIsActive() != null ? dto.getQuranicSeniorityIsActive() : entity.getQuranicSeniorityIsActive());

        return repository.save(entity);
    }

    public Page<QuranicSeniority> getQuranicSeniorities(String type,String amount, Boolean isActive,Integer fromAmount, Integer toAmount, int page, int size) {
        Specification<QuranicSeniority> spec = Specification
                .where(QuranicSenioritySpecification.filterByType(type))
                .and(QuranicSenioritySpecification.filterByAmount(amount))
                .and(QuranicSenioritySpecification.filterByMaxAmountRange(fromAmount, toAmount))

                .and(QuranicSenioritySpecification.filterByStatus(isActive));

        return repository.findAll(spec, PageRequest.of(page, size));
    }

    public void deleteQuranicSeniority(UUID id) {
        repository.deleteById(id);
    }

    public Optional<QuranicSeniority> getQuranicSeniorityById(UUID id) {
        return repository.findById(id);
    }
}
