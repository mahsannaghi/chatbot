package com.paya.EncouragementService.controller;

import com.paya.EncouragementService.dto.EncouragementCreateRequestSpecial;
import com.paya.EncouragementService.dto.PaginationResponseDTO;
import com.paya.EncouragementService.dto.PersonnelDTO;
import com.paya.EncouragementService.dto.v2.EncouragementFilterDTOV2;
import com.paya.EncouragementService.dto.v2.PersonnelListEncouragementFilterDTO;
import com.paya.EncouragementService.entity.Encouragement;
import com.paya.EncouragementService.entity.TblUser;
import com.paya.EncouragementService.enumeration.EncouragementResultEnum;
import com.paya.EncouragementService.service.AuthService;
import com.paya.EncouragementService.service.EncouragementService;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/encouragements")
@PreAuthorize("hasAnyRole('Manager')")
@AllArgsConstructor
public class EncouragementController {

    private final EncouragementService encouragementService;
    private final AuthService authService;


//    @GetMapping
//    public ResponseEntity<List<EncouragementDTO>> getAllEncouragements(
//            @RequestParam(required = false) UUID relatedPersonnelIds,
//            @RequestParam(required = false) UUID registrarPersonnelId,
//            @RequestParam(required = false) UUID approverPersonnelId,
//            @RequestParam(required = false) UUID reasonTypeId,
//            @RequestParam(required = false) String encouragementNumber,
//            @RequestParam(required = false) Date createdAt,
//            @RequestParam(required = false) Date approvedAt,
//            @RequestParam(required = false) Double minAmount,
//            @RequestParam(required = false) Double maxAmount,
//            @RequestParam(required = false) Integer encouragementStatus
//    ) {
//
//
//        List<EncouragementDTO> encouragements = encouragementService.getAllEncouragements(
//                relatedPersonnelIds, registrarPersonnelId, approverPersonnelId, reasonTypeId,
//                encouragementNumber, createdAt, approvedAt, minAmount, maxAmount, encouragementStatus);
//
//        List<EncouragementDTO> encouragementList = encouragements;
//        return ResponseEntity.ok(encouragementList);
//    }


    @PostMapping("getCartablEncouragementList")
    public ResponseEntity<Page<EncouragementFilterDTOV2>> getCartablEncouragementList(@RequestBody(required = false) EncouragementFilterDTOV2 filterDTO, @RequestParam(defaultValue = "0") Integer pageNumber, @RequestParam(defaultValue = "5") Integer pageSize) throws Exception {
        try {
            if (filterDTO.getEncouragementRegistrarOrganizationId() == null) {
                TblUser user = authService.getIsLoginUser();
                filterDTO.setEncouragementRegistrarOrganizationId(user.getUsername());
            }
            return ResponseEntity.ok().body(encouragementService.getEncouragementList(filterDTO, PageRequest.of(pageNumber, pageSize)));
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @PostMapping("getUserPanelEncouragementList")
    public ResponseEntity<Page<EncouragementFilterDTOV2>> getUserPanelEncouragementList(@RequestBody(required = false) EncouragementFilterDTOV2 filterDTO, @RequestParam(defaultValue = "0") Integer pageNumber, @RequestParam(defaultValue = "5") Integer pageSize) throws Exception {
        try {
            if (filterDTO.getEncouragementPersonnelOrganizationId() == null) {
                TblUser user = authService.getIsLoginUser();
                filterDTO.setEncouragementPersonnelOrganizationId(user.getUsername());
                filterDTO.setEncouragementStatusNot(EncouragementResultEnum.UNDER_REVIEW.getCode());
            }
            return ResponseEntity.ok().body(encouragementService.getEncouragementList(filterDTO, PageRequest.of(pageNumber, pageSize)));
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    @PostMapping("getPersonnelListEncouragement")
    public ResponseEntity<PaginationResponseDTO<? extends PersonnelDTO>> getPersonnelListEncouragement(@RequestBody(required = false) PersonnelListEncouragementFilterDTO dto, @RequestParam(defaultValue = "0") Integer pageNumber, @RequestParam(defaultValue = "5") Integer pageSize) throws Exception {
        try {
            TblUser user = authService.getIsLoginUser();
            return ResponseEntity.ok().body(encouragementService.getPersonnelListEncouragement(dto, user, PageRequest.of(pageNumber, pageSize)));
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }


//    @PostMapping
//    public ResponseEntity<Map<String, Object>> createEncouragement(@RequestBody EncouragementCreateRequestSpecial request) throws Exception {
//        List<Encouragement> createdEncouragements = encouragementService.createEncouragement(request);
//        Map<String, Object> response = new HashMap<>();
//        response.put("status", "Created successfully");
//        List<UUID> punishmentIds = createdEncouragements.stream()
//                .map(Encouragement::getEncouragementId)
//                .collect(Collectors.toList());
//        response.put("encouragementIds", punishmentIds);
//        if (createdEncouragements.isEmpty()) {
//            response.put("status", "No punishments created");
//            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(response);
//        }
//        return ResponseEntity.status(HttpStatus.CREATED).body(response);
//    }

    @PostMapping
    public ResponseEntity<List<Encouragement>> addEncouragement(@RequestBody EncouragementCreateRequestSpecial encouragementCreateDTO) throws Exception {
        try {
            List<Encouragement> encouragementList = encouragementService.addOrUpdateEncouragement(encouragementCreateDTO);
            return ResponseEntity.ok().body(encouragementList);
        } catch (Exception e) {
            throw new Exception(e);
        }
    }


//    @PatchMapping("/{id}")
//    public ResponseEntity<Encouragement> updateEncouragement(
//            @PathVariable UUID id,
//            @RequestBody EncouragementCreateRequestSpecial request) {
//        Encouragement updatedEncouragement = encouragementService.updateEncouragement(id, request);
//        return ResponseEntity.ok(updatedEncouragement);
//    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deletePunishment(@PathVariable UUID id) {
        encouragementService.deleteEncouragement(id);

        Map<String, String> response = new HashMap<>();
        response.put("status", "Deleted successfully");

        return ResponseEntity.ok(response);
    }


}
