package com.paya.EncouragementService.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PersonnelManagerDTO {
    private String personnelManagerOrganizationId;
    private Integer personnelManagerLevel;
    private String personnelManagerPosition;
}