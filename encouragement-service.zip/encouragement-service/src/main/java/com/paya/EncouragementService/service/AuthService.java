package com.paya.EncouragementService.service;


import com.paya.EncouragementService.dto.PersonnelDTO;
import com.paya.EncouragementService.entity.TblUser;
import com.paya.EncouragementService.feign.auth.AuthFeign;
import com.paya.EncouragementService.repository.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
@Transactional
public class AuthService {
    // This class is used to get current user by access token of header in each request
    private final UserRepository userRepository;
    private final JwtDecoder jwtDecoder;
    private final AuthFeign authFeign;
    private final PersonnelService personnelService;

    public AuthService(UserRepository userRepository, JwtDecoder jwtDecoder, AuthFeign authFeign, PersonnelService personnelService) {
        this.userRepository = userRepository;
        this.jwtDecoder = jwtDecoder;
        this.authFeign = authFeign;
        this.personnelService = personnelService;
    }

    private TblUser createUser(String username) {
        // If there is not this current user in database, add new user to User table
        String uuid;
        TblUser user = new TblUser();
        user.setUsername(username);
        do {
            uuid = UUID.randomUUID().toString();
            uuid = uuid.replace("-", "");
        } while (this.userRepository.existsByUserId(uuid));

        user.setUserId(uuid);
        userRepository.save(user);

        return user;
    }

    public TblUser getIsLoginUser() throws Exception {
        // This method is used to extract current user after login by access token
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        String username;
        String authHeader = request.getHeader("Authorization");

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            Map<String, Object> userInfo = authFeign.getUserInfo(authHeader);
            String userId = (String) userInfo.get("userId");
            String preferredUsername = (String) userInfo.get("preferred_username");
            List<HashMap<String, Integer>> objectKeys = (List<HashMap<String, Integer>>) userInfo.get("objectKeys");
            username = preferredUsername;
            if (userId != null && username == null) {
                username = userId;
            }
            TblUser user = userRepository.findByUsername(username);
            if (user == null) {
                user = this.createUser(username);
            }
            if (user.getUserInfo() == null) {
                PersonnelDTO personnelDto = personnelService.findByOrganizationId(user.getUsername());
                if (personnelDto == null) {
                    return null;
                }
                user.setUserInfo(personnelDto);
                user.setRoles(objectKeys);
            }
            return user;
        }
        return null;
    }
}
