package com.paya.EncouragementService.enumeration;

import org.springframework.stereotype.Component;

@Component
public class RoleConstant {

    // All roles in pleaser service
    public enum ROLE {
        PERSONNEL(0),
        EXECUTIVE_MANAGER(1),
        ENCOURAGEMENT_SPECIALIST(2),
        COMMISSION(3),
        VEDJA(4);

        private final Integer value;

        ROLE(Integer value) {
            this.value = value;
        }

        public Integer getValue() {
            return value;
        }

        public static ROLE fromValue(int value) {
            for (ROLE role : ROLE.values()) {
                if (role.getValue().equals(value)) {
                    return role;
                }
            }
            return null;
        }
    }
}
