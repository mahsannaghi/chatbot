package com.paya.EncouragementService.controller;

import com.paya.EncouragementService.dto.RegistrarPowerLimitsDTO;
import com.paya.EncouragementService.dto.RegistrarPowerLimitsRequestDTO;
import com.paya.EncouragementService.service.RegistrarPowerLimitsService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/registrar-power-limits")
@PreAuthorize("hasAnyRole('Manager')")
public class RegistrarPowerLimitsController {

    private final RegistrarPowerLimitsService registrarPowerLimitsService;

    public RegistrarPowerLimitsController(RegistrarPowerLimitsService registrarPowerLimitsService) {
        this.registrarPowerLimitsService = registrarPowerLimitsService;
    }



    @PostMapping("search")
    public List<RegistrarPowerLimitsDTO> getRegistrarPowerLimitsWithExternalData(@RequestBody RegistrarPowerLimitsRequestDTO requestDTO) {
        return registrarPowerLimitsService.getRegistrarPowerLimitsWithExternalData(requestDTO);
    }

    @PostMapping("/update")
    public ResponseEntity<String> saveRegistrarPowerLimits(@RequestBody RegistrarPowerLimitsRequestDTO requestDTO) {
        try {
            registrarPowerLimitsService.saveRegistrarPowerLimits(requestDTO);
            return ResponseEntity.ok("Request processed successfully");
        } catch (IllegalArgumentException e) {

            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Validation error: " + e.getMessage());
        } catch (Exception e) {

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An unexpected error occurred: " + e.getMessage());
        }
    }


    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleException(Exception e) {

        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body("An unexpected error occurred: " + e.getMessage());
    }


}
