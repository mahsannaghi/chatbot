package com.paya.EncouragementService.Specification;

import com.paya.EncouragementService.dto.RegistrarPowerLimitsRequestDTO;
import com.paya.EncouragementService.entity.RegistrarPowerLimits;
import com.paya.EncouragementService.entity.EncouragementType;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.persistence.criteria.Subquery;
import org.springframework.data.jpa.domain.Specification;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class RegistrarPowerLimitsSpecification {

    public static Specification<RegistrarPowerLimits> filterByCriteria(RegistrarPowerLimitsRequestDTO dto) {

        return (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if (dto.getRankTypeCode() != null) {
                predicates.add(criteriaBuilder.equal(root.get(RegistrarPowerLimitsRequestDTO.Fields.rankTypeCode),
                        dto.getRankTypeCode()));
            }
            if (dto.getJobPositionCode() != null) {
                predicates.add(criteriaBuilder.equal(root.get(RegistrarPowerLimitsRequestDTO.Fields.jobPositionCode),
                        dto.getJobPositionCode()));
            }
            if (dto.getRankTypeCivilianCode() != null) {
                dto.setRankTypeCivilianCode(dto.getRankTypeCivilianCode() - 11);
                predicates.add(criteriaBuilder.equal(root.get(RegistrarPowerLimitsRequestDTO.Fields.rankTypeCivilianCode),
                        dto.getRankTypeCivilianCode()));
            }
            if (dto.getRankTypeCivilianCodeList() != null) {
                List<Integer> list = dto.getRankTypeCivilianCodeList().stream().map(a -> a - 11).toList();
                dto.setRankTypeCivilianCodeList(list);
                Path<Integer> rankTypeCivilianCodePath = root.get(RegistrarPowerLimitsRequestDTO.Fields.rankTypeCode);
                predicates.add(rankTypeCivilianCodePath.in(dto.getRankTypeCivilianCodeList()));
            }
            if (dto.getRankTypeCodeList() != null) {
                Path<Integer> rankTypeCodePath = root.get(RegistrarPowerLimitsRequestDTO.Fields.rankTypeCode);
                predicates.add(rankTypeCodePath.in(dto.getRankTypeCodeList()));
            }
            if (dto.getJobPositionCodeList() != null) {
                Path<Integer> rankTypeCivilianCodePath = root.get(RegistrarPowerLimitsRequestDTO.Fields.jobPositionCode);
                predicates.add(rankTypeCivilianCodePath.in(dto.getJobPositionCodeList()));
            }
            if (dto.getTypeTitleList() != null && dto.getTypeTitleList().size() > 0) {
                List<String> typeTitleList = dto.getTypeTitleList().stream()
                        .map(title -> title.toLowerCase().trim()).toList();
                Subquery<UUID> typeSubquery = query.subquery(UUID.class);
                Root<EncouragementType> typeRoot = typeSubquery.from(EncouragementType.class);

                List<Predicate> likePredicates = typeTitleList.stream()
                        .map(title -> criteriaBuilder.like(
                                criteriaBuilder.lower(typeRoot.get("encouragementTypeTitle")), "%" + title + "%"))
                        .collect(Collectors.toList());

                typeSubquery.select(typeRoot.get("encouragementTypeId"))
                        .where(criteriaBuilder.or(likePredicates.toArray(new Predicate[0])));

                predicates.add(root.get("encouragementTypeId").in(typeSubquery));
//                typeSubquery.select(typeRoot.get("encouragementTypeId"))
//                        .where(typeRoot.get("encouragementTypeTitle").in(typeTitleList));
//
//                predicates.add(root.get("encouragementTypeId").in(typeSubquery));
            }
            if (dto.getTypeTitle() != null && !dto.getTypeTitle().trim().isEmpty()) {
                String typeTitle = dto.getTypeTitle().toLowerCase().trim();
                Subquery<UUID> typeSubquery = query.subquery(UUID.class);
                Root<EncouragementType> typeRoot = typeSubquery.from(EncouragementType.class);

                typeSubquery.select(typeRoot.get("encouragementTypeId"))
                        .where(criteriaBuilder.like(
                                criteriaBuilder.lower(typeRoot.get("encouragementTypeTitle")),
                                "%" + typeTitle + "%"
                        ));

                predicates.add(root.get("encouragementTypeId").in(typeSubquery));
            }

            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }


}
