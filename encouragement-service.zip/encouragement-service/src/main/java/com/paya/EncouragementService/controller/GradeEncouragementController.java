package com.paya.EncouragementService.controller;

import com.paya.EncouragementService.dto.GradeEncouragementInsertDTO;
import com.paya.EncouragementService.dto.v2.GradeEncouragementDTOV2;
import com.paya.EncouragementService.dto.v2.GradeEncouragementFilterDTOV2;
import com.paya.EncouragementService.entity.GradeEncouragement;
import com.paya.EncouragementService.service.GradeEncouragementService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/api/grade-encouragements")
@PreAuthorize("hasAnyRole('Manager')")
public class GradeEncouragementController {

    @Autowired
    private GradeEncouragementService service;


    @PostMapping
    public GradeEncouragementInsertDTO createGradeEncouragement(@RequestPart("data") String dto, @RequestPart(required = false, name = "files")  List<MultipartFile> files) throws Exception {
        return service.createGradeEncouragement(dto, files);
    }

    @PatchMapping
    public GradeEncouragement updateGradeEncouragement(@RequestBody @Valid GradeEncouragementInsertDTO dto) {
        return service.updateGradeEncouragement(dto);
    }


    @GetMapping("/{id}")
    public GradeEncouragement getGradeEncouragement(@PathVariable UUID id) {
        return service.getGradeEncouragementById(id)
                .orElseThrow(() -> new IllegalArgumentException("GradeEncouragement not found"));
    }


    //    @GetMapping
//    public Page<GradeEncouragementDTOV2> getGradeEncouragements(@RequestParam(required = false, defaultValue = "5") Integer pageSize,
//                                                                @RequestParam(required = false, defaultValue = "0") Integer pageNumber) throws ExecutionException, InterruptedException {
//        return service.getList(PageRequest.of(pageNumber, pageSize));
//    }
    @PostMapping("/filter")
    public Page<GradeEncouragementDTOV2> getGradeEncouragements(
            @RequestBody GradeEncouragementFilterDTOV2 filterDTO,
            @RequestParam(required = false, defaultValue = "5") Integer pageSize,
            @RequestParam(required = false, defaultValue = "0") Integer pageNumber) throws Exception {
        return service.getList(filterDTO, pageSize, pageNumber);
    }


    @DeleteMapping("/{id}")
    public void deleteGradeEncouragement(@PathVariable UUID id) {
        service.deleteGradeEncouragement(id);
    }


}
