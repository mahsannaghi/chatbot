package com.paya.EncouragementService.dto;

import lombok.*;

import java.util.List;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
public class RegistrarPowerLimitsDTO {
//    private UUID jobPositionId;
//    private UUID gradeId;
    private UUID id;
    private Integer jobPositionCode;
    private String rankTypePersianName;
    private Integer rankTypeCode;
    private Integer rankTypeCivilian;
    private String jobPositionPersianName;
//    private String jobPositionTitle;
//    private String gradeTitle;
//    private String degreeTitle;
//    private GradeDTO grade;
//    private PositionDTO position;
    private List<PowerTypesDTO> types;


}

