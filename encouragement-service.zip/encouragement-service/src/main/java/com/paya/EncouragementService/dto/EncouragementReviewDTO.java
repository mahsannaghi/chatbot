package com.paya.EncouragementService.dto;

import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@Data
public class EncouragementReviewDTO {
    private UUID encouragementReviewId; // nullable for new records
    @NotNull(message = "Encouragement ID is required")
    private UUID encouragementReviewEncouragementId;
//    @NotNull(message = "Registrar Personnel ID is required")
//    private UUID encouragementReviewRegistrarPersonnelId;

    @NotNull(message = "Registrar Personnel ID is required")
    private String encouragementReviewRegistrarOrganizationId;
    @NotNull(message = "Paying Authority ID is required")
    private UUID encouragementReviewPayingAuthorityId;
    @NotNull(message = "Encouragement Type ID is required")
    private UUID encouragementReviewEncouragementTypeId;
    private PersonnelDTO encouragementReviewRegistrarPersonnelDTO;
    private PersonnelDTO encouragementReviewEncouragementPersonnelDTO;
    private EncouragementDTO encouragementDTO;
    @NotNull(message = "Review Result is required")
    private Integer encouragementReviewResult;
    private String encouragementReviewDescription;
    @NotNull(message = "Created At is required")
    private LocalDateTime encouragementReviewCreatedAt;
    private Double encouragementReviewAmount;
    private Integer encouragementReviewAmountType;
    private Integer encouragementReviewPercentage;
    @NotNull(message = "Review Type is required")
    private Integer encouragementReviewType;
    private LocalDateTime encouragementReviewUpdatedAt;
    private LocalDate encouragementReviewSentDraftDate;
    private String encouragementReviewOrganizationId;
    private Integer encouragementReviewDraft;
    private LocalDate encouragementReviewAppliedDate;
    public EncouragementReviewDTO(UUID encouragementReviewId, String encouragementReviewRegistrarOrganizationId, UUID encouragementReviewPayingAuthorityId, UUID encouragementReviewEncouragementTypeId, Integer encouragementReviewResult, String encouragementReviewDescription, Double encouragementReviewAmount, Integer encouragementReviewAmountType, Integer encouragementReviewPercentage, Integer encouragementReviewType, LocalDate encouragementReviewSentDraftDate, String encouragementReviewOrganizationId, LocalDate encouragementReviewAppliedDate, Integer encouragementReviewDraft) {
        this.encouragementReviewId = encouragementReviewId;
        this.encouragementReviewRegistrarOrganizationId = encouragementReviewRegistrarOrganizationId;
        this.encouragementReviewPayingAuthorityId = encouragementReviewPayingAuthorityId;
        this.encouragementReviewEncouragementTypeId = encouragementReviewEncouragementTypeId;
        this.encouragementReviewResult = encouragementReviewResult;
        this.encouragementReviewDescription = encouragementReviewDescription;
        this.encouragementReviewAmount = encouragementReviewAmount;
        this.encouragementReviewAmountType = encouragementReviewAmountType;
        this.encouragementReviewPercentage = encouragementReviewPercentage;
        this.encouragementReviewType = encouragementReviewType;
        this.encouragementReviewSentDraftDate = encouragementReviewSentDraftDate;
        this.encouragementReviewOrganizationId = encouragementReviewOrganizationId;
        this.encouragementReviewAppliedDate = encouragementReviewAppliedDate;
        this.encouragementReviewDraft = encouragementReviewDraft;
    }
}
