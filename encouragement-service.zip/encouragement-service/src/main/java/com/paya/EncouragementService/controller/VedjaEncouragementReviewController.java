package com.paya.EncouragementService.controller;


import com.paya.EncouragementService.dto.EncouragementReviewDTO;
import com.paya.EncouragementService.service.EncouragementReviewService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("vedja")
@AllArgsConstructor
@PreAuthorize("hasAnyRole('Vedja')")
public class VedjaEncouragementReviewController {
    private final EncouragementReviewService encouragementReviewService;


    @GetMapping
    public ResponseEntity<List<EncouragementReviewDTO>> getAllReviews() {
        return ResponseEntity.ok().body(encouragementReviewService.getAllForVedja());
    }
}
