package com.paya.EncouragementService.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.paya.EncouragementService.Specification.GradeEncouragementSpecification;
import com.paya.EncouragementService.dto.GradeEncouragementDTO;
import com.paya.EncouragementService.dto.GradeEncouragementInsertDTO;
import com.paya.EncouragementService.dto.PersonnelDTO;
import com.paya.EncouragementService.dto.v2.AttachmentGetDTO;
import com.paya.EncouragementService.dto.v2.GradeEncouragementDTOV2;
import com.paya.EncouragementService.dto.v2.GradeEncouragementFilterDTOV2;
import com.paya.EncouragementService.entity.GradeEncouragement;
import com.paya.EncouragementService.enumeration.DegreeEnum;
import com.paya.EncouragementService.repository.GradeEncouragementRepository;
import com.paya.EncouragementService.repository.v2.GradeEncouragementDAO;
import com.paya.EncouragementService.service.v2.AttachmentService;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import paya.net.exceptionhandler.Exception.GeneralException;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class GradeEncouragementService {


    private final GradeEncouragementRepository repository;
    private final GradeEncouragementDAO gradeEncouragementDAO;
    private final PersonnelService personnelService;
    private final UpgradeDegreeSeniorityService upgradeDegreeSeniorityService;
    private final AttachmentService attachmentService;

    public GradeEncouragementService(GradeEncouragementRepository repository, GradeEncouragementDAO gradeEncouragementDAO, PersonnelService personnelService, UpgradeDegreeSeniorityService upgradeDegreeSeniorityService, AttachmentService attachmentService) {
        this.repository = repository;
        this.gradeEncouragementDAO = gradeEncouragementDAO;
        this.personnelService = personnelService;
        this.upgradeDegreeSeniorityService = upgradeDegreeSeniorityService;
        this.attachmentService = attachmentService;
    }

    @Transactional
    public GradeEncouragementInsertDTO createGradeEncouragement(String dto, List<MultipartFile> files) throws Exception {
        if (dto != null) {
            ObjectMapper objectMapper = new ObjectMapper();
            GradeEncouragementInsertDTO encouragementDTO = objectMapper.readValue(dto, GradeEncouragementInsertDTO.class);
            GradeEncouragement entity = new GradeEncouragement();
            entity.setGradeEncouragementNewGrade(encouragementDTO.getGradeEncouragementNewGrade());
//        TODO fill from keyclock
            entity.setGradeEncouragementRegistrarPersonnelId(new UUID(0, 10));
            entity.setGradeEncouragementRelatedPersonnelId(encouragementDTO.getGradeEncouragementRelatedPersonnelId());
            GradeEncouragement finalEntity = repository.save(entity);
            if (files != null) {
                attachmentService.addAttachmentForGradeEncouragement(files, finalEntity.getGradeEncouragementId());
            }
            return encouragementDTO;
        } else throw new GeneralException("پارامتر ورودی صحیح نمی باشد .");
    }

    public GradeEncouragement updateGradeEncouragement(GradeEncouragementInsertDTO dto) {

        GradeEncouragement entity = repository.findById(dto.getGradeEncouragementId())
                .orElseThrow(() -> new GeneralException("Entity with ID not found"));


        entity.setGradeEncouragementNewGrade(dto.getGradeEncouragementNewGrade());
        entity.setGradeEncouragementRegistrarPersonnelId(dto.getGradeEncouragementRegistrarPersonnelId());
        entity.setGradeEncouragementRelatedPersonnelId(dto.getGradeEncouragementRelatedPersonnelId());


        return repository.save(entity);
    }


    public List<GradeEncouragementDTO> getGradeEncouragements(
            Integer newGrade,
            String registrarPersonnelId,
            String relatedPersonnelId,
            java.sql.Date createdAt,
            java.sql.Date updatedAt) {

        Specification<GradeEncouragement> spec = Specification.where(null);

        if (newGrade != null) {
            spec = spec.and(GradeEncouragementSpecification.filterByNewGrade(newGrade));
        }
        if (registrarPersonnelId != null) {
            spec = spec.and(GradeEncouragementSpecification.filterByRegistrarPersonnelId(registrarPersonnelId));
        }
        if (relatedPersonnelId != null) {
            spec = spec.and(GradeEncouragementSpecification.filterByRelatedPersonnelId(relatedPersonnelId));
        }
        if (createdAt != null) {
            spec = spec.and(GradeEncouragementSpecification.filterByCreatedAt(createdAt));
        }
        if (updatedAt != null) {
            spec = spec.and(GradeEncouragementSpecification.filterByUpdatedAt(updatedAt));
        }

        // اجرای جستجو با فیلترهای اعمال شده
        List<GradeEncouragement> gradeEncouragements = repository.findAll(spec);

        // تبدیل موجودیت‌ها به DTO
        return gradeEncouragements.stream()
                .map(this::convertToGradeEncouragementDTO)
                .collect(Collectors.toList());
    }

    private GradeEncouragementDTO convertToGradeEncouragementDTO(GradeEncouragement gradeEncouragement) {
        GradeEncouragementDTO dto = new GradeEncouragementDTO();

        dto.setGradeEncouragementId(gradeEncouragement.getGradeEncouragementId());
        dto.setGradeEncouragementNewGrade(gradeEncouragement.getGradeEncouragementNewGrade());
       /* dto.setRegistrarPersonnelId(gradeEncouragement.getRegistrarPersonnelId());
        dto.setRelatedPersonnelId(gradeEncouragement.getRelatedPersonnelId());*/

        if (gradeEncouragement.getGradeEncouragementRelatedPersonnelId() != null) {
            List<PersonnelDTO> byPersonnelIdList = personnelService.findByPersonnelIdList(Collections.singletonList(gradeEncouragement.getGradeEncouragementRelatedPersonnelId()));
            if (byPersonnelIdList.size() > 0) {
                dto.setGradeEncouragementRelatedPersonnelId(byPersonnelIdList.get(0));
            }

        }

        if (gradeEncouragement.getGradeEncouragementRegistrarPersonnelId() != null) {
            List<PersonnelDTO> byPersonnelIdList = personnelService.findByPersonnelIdList(Collections.singletonList(gradeEncouragement.getGradeEncouragementRegistrarPersonnelId()));
            if (byPersonnelIdList.size() > 0) {
                dto.setGradeEncouragementRegistrarPersonnelId(byPersonnelIdList.get(0));
            }

        }


        dto.setGradeEncouragementCreatedAt(gradeEncouragement.getGradeEncouragementCreatedAt());
        dto.setGradeEncouragementUpdatedAt(gradeEncouragement.getGradeEncouragementUpdatedAt());


        return dto;
    }


    public void deleteGradeEncouragement(UUID id) {
        repository.deleteById(id);
    }

    public Optional<GradeEncouragement> getGradeEncouragementById(UUID id) {
        return repository.findById(id);
    }


    public Page<GradeEncouragementDTOV2> getList(GradeEncouragementFilterDTOV2 gradeEncouragementFilterDTO, Integer pageSize, Integer pageNumber) throws Exception {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        Page<GradeEncouragementDTOV2> resultPage = gradeEncouragementDAO.getList(PageRequest.of(pageNumber, pageSize),
                gradeEncouragementFilterDTO.getFromDate() != null ? LocalDate.parse(gradeEncouragementFilterDTO.getFromDate(), formatter).atStartOfDay() : null,
                gradeEncouragementFilterDTO.getToDate() != null ? LocalDate.parse(gradeEncouragementFilterDTO.getToDate(), formatter).atStartOfDay() : null,
                gradeEncouragementFilterDTO.getGradeEncouragementNewGrade());

        List<GradeEncouragementDTOV2> resultList = resultPage.getContent();
        List<GradeEncouragementDTOV2> finalResultList = new ArrayList<>();
        //filtering personnel with entries
        if (gradeEncouragementFilterDTO.getPersonnel() != null) {
            List<PersonnelDTO> personnelList = personnelService.getFilteredPersonnel(gradeEncouragementFilterDTO.getPersonnel());
            if (!personnelList.isEmpty()) {
                for (GradeEncouragementDTOV2 dto : resultList) {
                    for (PersonnelDTO person : personnelList) {
                        boolean condition = String.valueOf(dto.getGradeEncouragementRelatedPersonnelId()).equals(person.getPersonnelId());
                        if (condition) {
                            finalResultList.add(dto);
                        }
                    }
                }
            }
        } else {
            finalResultList.addAll(resultList);
        }
        if (!finalResultList.isEmpty()) {
//            filling Personnel Degree and files
            for (GradeEncouragementDTOV2 dto : finalResultList) {
                PersonnelDTO personnelDto = personnelService.findById(dto.getGradeEncouragementRelatedPersonnelId());
                List<AttachmentGetDTO> attachmentGetDTOList = attachmentService.getAllGradeEncouragementAttachments(PageRequest.of(0, 9000), dto.getGradeEncouragementId());
                if (personnelDto != null) {
                    dto.setPersonnel(personnelDto);
                    Integer lastDegree = personnelDto.getPersonnelDegreeCode();
                    Integer newDegree = dto.getGradeEncouragementNewGrade();

                    if (lastDegree != null && newDegree != null) {
                        Integer maxAmount = upgradeDegreeSeniorityService.getMaxAmountWithLastDegreeAndNewDegree(lastDegree, newDegree);
                        DegreeEnum newGradeTitle = Arrays.stream(DegreeEnum.values()).filter(item -> item.getDegreeCode().equals(newDegree)).findFirst().orElseThrow();
                        dto.setSeniorityAmount(maxAmount);
                        dto.setGradeEncouragementNewGradeTitle(newGradeTitle.getDegreeTitle());
                    }
                }
                if (!attachmentGetDTOList.isEmpty()) {
                    dto.setFiles(attachmentGetDTOList);
                }
            }
//            filtering with new grade title
            if (gradeEncouragementFilterDTO.getGradeEncouragementNewGradeTitle() != null) {
                finalResultList = finalResultList.stream()
                        .filter(dto -> dto.getGradeEncouragementNewGradeTitle().contains(gradeEncouragementFilterDTO.getGradeEncouragementNewGradeTitle()))
                        .toList();
            }
            //filtering with seniority amount
            if (gradeEncouragementFilterDTO.getSeniorityAmount() != null) {
                finalResultList = finalResultList.stream()
                        .filter(dto -> dto.getSeniorityAmount().equals(gradeEncouragementFilterDTO.getSeniorityAmount()))
                        .toList();
            }
        }
        return new PageImpl<>(finalResultList, PageRequest.of(pageNumber, pageSize), resultPage.getTotalElements());
    }
}
