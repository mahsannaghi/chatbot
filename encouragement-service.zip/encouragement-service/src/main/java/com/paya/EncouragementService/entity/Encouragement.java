package com.paya.EncouragementService.entity;

import com.paya.EncouragementService.enumeration.DraftEnum;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Random;
import java.util.UUID;

@Entity
@Table(name = "tbl_encouragement")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Encouragement {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID encouragementId;


//    @Column(name = "encouragement_related_personnel_id", columnDefinition = "uniqueidentifier")
//    private UUID encouragementRelatedPersonnelId;

    @Column(name = "encouragement_personnel_organization_id")
    private String encouragementPersonnelOrganizationId;

//    @Column(name = "encouragement_registrar_personnel_id", columnDefinition = "uniqueidentifier")
//    private UUID encouragementRegistrarPersonnelId;

    @Column(name = "encouragement_registrar_organization_id")
    private String encouragementRegistrarOrganizationId;

//    @Column(name = "encouragement_approver_personnel_id", columnDefinition = "uniqueidentifier")
//    private UUID encouragementApproverPersonnelId;

    @Column(name = "encouragement_approver_organization_id", columnDefinition = "uniqueidentifier")
    private String encouragementApproverOrganizationId;

    @Column(name = "encouragement_reason_type_id", nullable = false, columnDefinition = "uniqueidentifier")
    private UUID encouragementReasonTypeId;

    @Column(name = "encouragement_number", nullable = false, length = 15)
    private String encouragementNumber;

    @Column(name = "encouragement_created_at")
    @CreationTimestamp
    private LocalDate encouragementCreatedAt;

    @Column(name = "encouragement_amount")
    private Long encouragementAmount;

    @Column(name = "encouragement_amount_type")
    private Integer encouragementAmountType;

    @Column(name = "encouragement_description")
    private String encouragementDescription;

    @Column(name = "encouragement_status")
    private Integer encouragementStatus;

    @Column(name = "encouragement_applied_date")
    private LocalDate encouragementAppliedDate;

    @Column(name = "encouragement_sent_draft_date")
    private LocalDate encouragementSentDraftDate;

    @Column(name = "encouragement_draft")
    @Enumerated(EnumType.ORDINAL)
    private DraftEnum encouragementDraft;

//    @Column(name = "encouragement_approved_at")
//    private String encouragementApprovedAt;

    @PrePersist
    private void generateEncouragementNumber() {
        if (this.encouragementNumber == null) {
            this.encouragementNumber = String.format("%015d", new Random().nextInt(1000000000));
        }
    }
}
