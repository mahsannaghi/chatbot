package com.paya.EncouragementService.dto.v2;


import lombok.*;
import lombok.experimental.FieldNameConstants;
import lombok.experimental.SuperBuilder;

@Getter
@Setter
@SuperBuilder
@Data
@FieldNameConstants
@NoArgsConstructor
@AllArgsConstructor
public class PersonnelFilterDTOV2 {
    private String personnelFirstName;
    private String personnelLastName;
    private String personnelUnitCode;
    private String personnelOrganizationId;
    private String personnelRank;
    private String type;
}
