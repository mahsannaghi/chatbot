package com.paya.EncouragementService.service;

import com.paya.EncouragementService.Specification.EncouragementSpecifications;
import com.paya.EncouragementService.dto.*;
import com.paya.EncouragementService.dto.v2.EncouragementFilterDTOV2;
import com.paya.EncouragementService.dto.v2.PersonnelFilterDTOV2;
import com.paya.EncouragementService.dto.v2.PersonnelListEncouragementFilterDTO;
import com.paya.EncouragementService.entity.*;
import com.paya.EncouragementService.enumeration.*;
import com.paya.EncouragementService.repository.EncouragementReasonTypeRepository;
import com.paya.EncouragementService.repository.EncouragementRepository;
import com.paya.EncouragementService.utility.PaginationUtils;
import jakarta.annotation.PostConstruct;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import paya.net.exceptionhandler.Exception.GeneralException;
import paya.net.exceptionhandler.Exception.ValidationException;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

@Service
@Slf4j
public class EncouragementService {
    private final EncouragementRepository encouragementRepository;
    private final EncouragementReasonTypeRepository encouragementReasonTypeRepository;
    private final PersonnelService personnelService;
    private final EncouragementReviewService encouragementReviewService;
    private final RegistrarPowerLimitsService registrarPowerLimitsService;
    private final EncouragementTypeService encouragementTypeService;
    private final AuthService authService;
    private final EncouragementReasonTypeService encouragementReasonTypeService;

    @Value("${encouragement.commissionList}")
    private String commissionList;


//    @Value("${objectKey.serviceRoleKey}")
//    private String roleKey;

//    @Value("${encouragement.typeOfBasePersonnelDTOSending}")
//    private String typeOfBasePersonnelDTOSending;

//    public List<EncouragementDTO> getAllEncouragements(UUID relatedPersonnelIds, UUID registrarPersonnelId, UUID approverPersonnelId, UUID reasonTypeId, String encouragementNumber, Date createdAt, Date approvedAt, Double minAmount, Double maxAmount, Integer encouragementStatus) {
//        Specification<Encouragement> spec = Specification.where(null);
//        if (relatedPersonnelIds != null) {
//            spec = spec.and(EncouragementSpecifications.hasRelatedPersonnelId2(relatedPersonnelIds));
//        }
//        if (registrarPersonnelId != null) {
//            spec = spec.and(EncouragementSpecifications.hasRegistrarPersonnelId(registrarPersonnelId));
//        }
//        if (approverPersonnelId != null) {
//            spec = spec.and(EncouragementSpecifications.hasApproverPersonnelId(approverPersonnelId));
//        }
//        if (reasonTypeId != null) {
//            spec = spec.and(EncouragementSpecifications.hasReasonTypeId(reasonTypeId));
//        }
//        if (encouragementNumber != null) {
//            spec = spec.and(EncouragementSpecifications.hasEncouragementNumber(encouragementNumber));
//        }
//        if (createdAt != null) {
//            spec = spec.and(EncouragementSpecifications.hasCreatedAt(createdAt));
//        }
//        if (approvedAt != null) {
//            spec = spec.and(EncouragementSpecifications.hasApprovedAt(approvedAt));
//        }
//        if (minAmount != null) {
//            spec = spec.and(EncouragementSpecifications.hasMinAmount(minAmount));
//        }
//        if (maxAmount != null) {
//            spec = spec.and(EncouragementSpecifications.hasMaxAmount(maxAmount));
//        }
//        if (encouragementStatus != null) {
//            spec = spec.and(EncouragementSpecifications.hasEncouragementStatus(encouragementStatus));
//        }
//        List<Encouragement> encouragements = encouragementRepository.findAll(spec);
//        return encouragements.stream().map(this::convertToEncouragementDTO).collect(Collectors.toList());
//    }


    public EncouragementService(EncouragementRepository encouragementRepository, EncouragementReasonTypeRepository encouragementReasonTypeRepository, PersonnelService personnelService, EncouragementReviewService encouragementReviewService, RegistrarPowerLimitsService registrarPowerLimitsService, EncouragementTypeService encouragementTypeService, AuthService authService, EncouragementReasonTypeService encouragementReasonTypeService) {
        this.encouragementRepository = encouragementRepository;
        this.encouragementReasonTypeRepository = encouragementReasonTypeRepository;
        this.personnelService = personnelService;
        this.encouragementReviewService = encouragementReviewService;
        this.registrarPowerLimitsService = registrarPowerLimitsService;
        this.encouragementTypeService = encouragementTypeService;
        this.authService = authService;
        this.encouragementReasonTypeService = encouragementReasonTypeService;
    }

    public PaginationResponseDTO<? extends PersonnelDTO> getPersonnelListEncouragement(PersonnelListEncouragementFilterDTO dto, TblUser user, PageRequest pageRequest) throws ExecutionException, InterruptedException {
        PersonnelDTO personnelDTO1 = user.getUserInfo();
        PersonnelResponseDTO resultResponse = new PersonnelResponseDTO();
        List<? extends PersonnelDTO> filteredList = new ArrayList<>();
        Integer roleCode = user.getRoles().get(0).get("encouragement_user_role");
        if (RoleConstant.ROLE.ENCOURAGEMENT_SPECIALIST.equals(RoleConstant.ROLE.fromValue(roleCode))) {
            Page<Encouragement> page = encouragementRepository.findAll(pageRequest);
            List<String> orgIdList = page.toList().stream().map(Encouragement::getEncouragementPersonnelOrganizationId).toList();
//            try {
            resultResponse = personnelService.findPageByOrgId(orgIdList);
//            } catch (ExecutionException | InterruptedException e) {
//                throw new RuntimeException(e);
//            }
        } else if (RoleConstant.ROLE.EXECUTIVE_MANAGER.equals(RoleConstant.ROLE.fromValue(roleCode))) {
            PersonnelDTO personnelDto = PersonnelDTO.builder().personnelUnitCode(personnelDTO1.getPersonnelUnitCode()).type("personnel").build();
            resultResponse = personnelService.getPersonnel(personnelDto);
//            List<? extends PersonnelDTO> personnelDTOList = responseDTO.getPersonnelDTOList();
//            List<String> orgIdList = personnelDTOList.stream().map(BasePersonnelDTO::getPersonnelOrganizationID).toList();
//            filterDTO.setEncouragementRelatedPersonnelOrganizationIdList(orgIdList);
//                encouragementPage = encouragementRepository.findByEncouragementRelatedPersonnelOrganizationId(orgIdList, pageable);
        } else if (RoleConstant.ROLE.PERSONNEL.equals(RoleConstant.ROLE.fromValue(roleCode))) {
            Page<EncouragementReview> page = encouragementReviewService.getEncouragementReviewsWithSpecification(
                    EncouragementReviewSearchDTO.builder().encouragementReviewRegistrarOrgIdNotEncouragementRegistrarOrgId(personnelDTO1.getPersonnelOrganizationID()).build(), pageRequest);
            List<String> orgIdList = page.stream().map(EncouragementReview::getEncouragementReviewEncouragementId).map(encouragementRepository::findByEncouragementId).filter(Optional::isPresent)
                    .map(Optional::get).filter(encouragement -> !encouragement.getEncouragementStatus().equals(EncouragementResultEnum.UNDER_REVIEW.getCode())).map(Encouragement::getEncouragementPersonnelOrganizationId).toList();
            if (orgIdList.size() > 0)
                resultResponse = personnelService.findPageByOrgId(orgIdList);
//                encouragementPage = encouragementRepository.findByEncouragementRelatedPersonnelOrganizationId(personnelDto1.getPersonnelOrganizationID() ,pageable);
//            filterDTO.setEncouragementRelatedPersonnelOrganizationId(personnelDTO1.getPersonnelOrganizationID());
        }
        if (resultResponse.getPersonnelDTOList() != null) {
            filteredList = resultResponse.getPersonnelDTOList().stream().filter(personnelDTO -> isMatching(personnelDTO, dto)).collect(Collectors.toList());
            resultResponse.setPersonnelDTOList(filteredList);
        }
        return PaginationUtils.paginate(filteredList, pageRequest);
//        catch (ExecutionException e) {
//            throw new RuntimeException(e);
//        } catch (InterruptedException e) {
//            throw new RuntimeException(e);
//        }
    }


    private boolean isMatching(PersonnelDTO person, PersonnelListEncouragementFilterDTO filter) {
        if (filter.getEncouragedPersonFirstName() != null) {
            filter.setEncouragedPersonFirstName(filter.getEncouragedPersonFirstName().replace("ی", "ي"));
//            filter.setPersonnelFirstName(filter.getPersonnelFirstName().replace("گ", "گ"));
            if (!person.getPersonnelFirstName().contains(filter.getEncouragedPersonFirstName()))
                return false;
        }
        if (filter.getEncouragedPersonLastName() != null) {
            filter.setEncouragedPersonLastName(filter.getEncouragedPersonLastName().replace("ی", "ي"));
            if (!person.getPersonnelLastName().contains(filter.getEncouragedPersonLastName()))
                return false;
        }
        if (filter.getEncouragementPersonnelOrganizationId() != null && !filter.getEncouragementPersonnelOrganizationId().equals(person.getPersonnelOrganizationID())) {
            return false;
        }
        return true;
    }

    public Page<EncouragementFilterDTOV2> getEncouragementList(EncouragementFilterDTOV2 filterDTO, Pageable pageable) throws Exception {
        if (filterDTO != null) {
            List<PersonnelDTO> basePersonnelWithFirstName = null;
            List<PersonnelDTO> basePersonnelWithLastName = null;
            List<String> firstNamePersonnelOrgId= null;
            List<String> lastNamePersonnelOrgId= null;
            if (filterDTO.getEncouragedPersonFirstName() != null) {
                basePersonnelWithFirstName = personnelService.getFilteredPersonnel(PersonnelFilterDTOV2.builder().personnelFirstName(filterDTO.getEncouragedPersonFirstName()).type("basePersonnel").build());
                if (basePersonnelWithFirstName == null || basePersonnelWithFirstName.size() == 0)
                    return new PageImpl<>(new ArrayList<>());
                else {
                    firstNamePersonnelOrgId = basePersonnelWithFirstName.stream().map(BasePersonnelDTO::getPersonnelOrganizationID).collect(Collectors.toList());
                    filterDTO.setEncouragementPersonnelOrganizationIdList(firstNamePersonnelOrgId);
                }
            } if (filterDTO.getEncouragedPersonLastName() != null) {
                basePersonnelWithLastName = personnelService.getFilteredPersonnel(PersonnelFilterDTOV2.builder().personnelLastName(filterDTO.getEncouragedPersonLastName()).type("basePersonnel").build());
                if (basePersonnelWithLastName == null || basePersonnelWithLastName.size() == 0)
                    return new PageImpl<>(new ArrayList<>());
                else {
                    lastNamePersonnelOrgId = basePersonnelWithLastName.stream().map(BasePersonnelDTO::getPersonnelOrganizationID).collect(Collectors.toList());
                    filterDTO.setEncouragementPersonnelOrganizationIdList(lastNamePersonnelOrgId);
                }
            }
            if (basePersonnelWithFirstName != null && basePersonnelWithFirstName.size() > 0 && basePersonnelWithLastName != null)  {
                if (firstNamePersonnelOrgId.size() >0 && lastNamePersonnelOrgId.size() >0)
                    firstNamePersonnelOrgId.retainAll(lastNamePersonnelOrgId);
                filterDTO.setEncouragementPersonnelOrganizationIdList(firstNamePersonnelOrgId);
            }
        }
        Page<Encouragement> encouragementPage = encouragementRepository.findAll(
                EncouragementSpecifications.filterBySpecification(filterDTO), pageable);
//            Page<Encouragement> encouragementPage = encouragementDAO.getList(pageable, filterDTO.getEncouragementNumber() != null ? filterDTO.getEncouragementNumber() : null, filterDTO.getEncouragementAmount() != null ? filterDTO.getEncouragementAmount() : null, filterDTO.getFromDate() != null ? filterDTO.getFromDate() : null, filterDTO.getToDate() != null ? filterDTO.getToDate() : null);
        return setPageDTOFromEncouragementPage(filterDTO, pageable, encouragementPage);
    }
//        } else throw new GeneralException("پارامتر ورودی صحیح نمی باشد . ");

    private PageImpl<EncouragementFilterDTOV2> setPageDTOFromEncouragementPage(EncouragementFilterDTOV2 filterDTO, Pageable pageable, Page<Encouragement> encouragementPage) throws ExecutionException, InterruptedException {
        List<EncouragementFilterDTOV2> finalList = new ArrayList<>();
        if (!encouragementPage.isEmpty()) {
            for (Encouragement encouragement : encouragementPage.getContent()) {
                EncouragementFilterDTOV2 encouragementDTO = new EncouragementFilterDTOV2();
                String reasonTitle = encouragementReasonTypeRepository.getReasonTitleWithReasonTypeId(encouragement.getEncouragementReasonTypeId());
                String typeTitle = encouragementReasonTypeRepository.getTypeTitleWithReasonTypeId(encouragement.getEncouragementReasonTypeId());
                PersonnelDTO encouragedPerson = personnelService.findByOrganizationId(encouragement.getEncouragementPersonnelOrganizationId());
                if (encouragedPerson != null) {
                    encouragementDTO.setEncouragedPersonFirstName(encouragedPerson.getPersonnelFirstName());
                    encouragementDTO.setEncouragedPersonLastName(encouragedPerson.getPersonnelLastName());
                    encouragementDTO.setEncouragementPersonnelOrganizationId(encouragedPerson.getPersonnelOrganizationID());
                    encouragementDTO.setEncouragedPersonUnitCode(encouragedPerson.getPersonnelUnitCode());
                    encouragementDTO.setEncouragedPersonRankTypePersianName(encouragedPerson.getPersonnelRankTypePersianName());
                    encouragementDTO.setEncouragedPersonRankTypeCivilianCode(encouragedPerson.getPersonnelRankTypeCivilianCode());
                }
                PersonnelDTO registrarPerson = personnelService.findByOrganizationId(encouragement.getEncouragementRegistrarOrganizationId());
                if (registrarPerson != null) {
                    encouragementDTO.setRegistrarPersonFirstName(registrarPerson.getPersonnelFirstName());
                    encouragementDTO.setRegistrarPersonLastName(registrarPerson.getPersonnelLastName());
                }
                if (reasonTitle != null && typeTitle != null) {
                    encouragementDTO.setEncouragementReason(reasonTitle);
                    encouragementDTO.setEncouragementType(typeTitle);
                }
                this.mapEntityToDTO(encouragement, encouragementDTO);
                finalList.add(encouragementDTO);
            }
            if (filterDTO.getEncouragedPersonLastName() != null) {
                finalList = finalList.stream().filter(item -> item.getEncouragedPersonLastName().contains(filterDTO.getEncouragedPersonLastName())).collect(Collectors.toList());
            }
            if (filterDTO.getEncouragementRegistrarOrganizationId() != null) {
                finalList = finalList.stream().filter(item -> item.getEncouragementRegistrarOrganizationId().equals(filterDTO.getEncouragementRegistrarOrganizationId())).collect(Collectors.toList());
            }
            if (filterDTO.getEncouragementReason() != null) {
                finalList = finalList.stream().filter(item -> item.getEncouragementReason().contains(filterDTO.getEncouragementReason())).collect(Collectors.toList());
            }
            if (filterDTO.getEncouragementType() != null) {
                finalList = finalList.stream().filter(item -> item.getEncouragementType().contains(filterDTO.getEncouragementType())).collect(Collectors.toList());
            }
            return new PageImpl<>(finalList, pageable, finalList.size());
        }
        return new PageImpl<>(finalList);
    }


    private EncouragementReasonTypeDetailDTO fetchReasonTypeDetails(UUID reasonTypeId) {
        return encouragementReasonTypeRepository.findReasonTypeDetailsById(reasonTypeId).orElseThrow(() -> new GeneralException("Details not found for reasonTypeId: " + reasonTypeId));
    }


    @Transactional
    public List<Encouragement> addOrUpdateEncouragement(EncouragementCreateRequestSpecial request) throws Exception {
        if (request != null && request.getEncouragementRelatedPersonnelOrganizationIds() != null) {
//            TODO get from current user
            PersonnelDTO registrar = personnelService.findByOrganizationId(authService.getIsLoginUser().getUsername());
            List<Encouragement> encouragements = new ArrayList<>();
            EncouragementReasonType reasonType = null;
            if (request.getReasonId() != null && request.getType() != null && request.getType().getTypeId() != null)
                reasonType = this.findReasonType(request.getReasonId(), request.getType().getTypeId());
//            boolean notSent = !request.getEncouragementDraft().equals(DraftEnum.Sent.getCode());
            boolean maxCondition = true;
            if (reasonType != null && reasonType.getMaxAmount() != null && !reasonType.getMaxAmount().equals(BigDecimal.ZERO) && request.getAmount() != null) {
                if ((reasonType.getMaxAmount().compareTo(BigDecimal.valueOf(request.getAmount())) < 0)) {
                    maxCondition = false;
                }
            } else if (reasonType != null && reasonType.getMaxDuration() != null && !reasonType.getMaxDuration().equals(0) && request.getAmount() != null) {
                if (request.getAmount() > reasonType.getMaxDuration())
                    maxCondition = false;
            }

            /** @CheckEntryAmountWithMaxAmount */
            if (maxCondition) {
                for (String personnelOrganizationId : request.getEncouragementRelatedPersonnelOrganizationIds()) {
                    PersonnelDTO encouragedPerson = personnelService.findByOrganizationId(personnelOrganizationId);
                    /** @CheckBothAreExistsInSameOrganization */
                    if ((registrar.getPersonnelUnitCode() == null || encouragedPerson.getPersonnelUnitCode() == null) || Objects.equals(registrar.getPersonnelUnitCode(), encouragedPerson.getPersonnelUnitCode())) {
                        /** @CheckExistsRegistrarInPersonnelManager */
//                        TODO uncommnet the below code on stage mode
                        if (encouragedPerson.getPersonnelManager() != null && encouragedPerson.getPersonnelManager().stream().anyMatch(manager -> manager.getPersonnelManagerOrganizationId().equals(registrar.getPersonnelOrganizationID()))) {
                            Encouragement encouragement = null;
                            UUID encouragementId = null;
                            boolean exitsById = false;
                            if (request.getEncouragementId() != null) {
                                encouragementId = request.getEncouragementId();
                            }
                            if (encouragementId != null) {
                                encouragement = encouragementRepository.findById(encouragementId).orElse(null);
                                if (encouragement != null) {
                                    if (encouragement.getEncouragementDraft().equals(DraftEnum.Sent) && !encouragement.getEncouragementStatus().equals(ReviewResultEnum.SENT_FOR_CORRECTION.getCode()))
                                        throw new ValidationException("این تشویق ارسال شده است و قابل ویرایش نمی باشد.");
                                    encouragement.setEncouragementId(request.getEncouragementId());
                                }
                            }
                            if (encouragement == null) {
                                encouragement = new Encouragement();
                                if (!DraftEnum.fromCode(request.getEncouragementDraft()).equals(DraftEnum.Sent))
                                    encouragement.setEncouragementStatus(EncouragementResultEnum.DRAFT.getCode());
                                else {
                                    encouragement.setEncouragementStatus(EncouragementResultEnum.UNDER_REVIEW.getCode());
                                    if (DraftEnum.fromCode(request.getEncouragementDraft()).equals(DraftEnum.Sent))
                                        encouragement.setEncouragementSentDraftDate(LocalDate.now());
                                }
                            }

                            if (encouragement.getEncouragementStatus() != null && !encouragement.getEncouragementStatus().equals(ReviewResultEnum.SENT_FOR_CORRECTION.getCode())) {
                                if (!DraftEnum.fromCode(request.getEncouragementDraft()).equals(DraftEnum.Sent))
                                    encouragement.setEncouragementStatus(EncouragementResultEnum.DRAFT.getCode());
                                else {
                                    encouragement.setEncouragementStatus(EncouragementResultEnum.UNDER_REVIEW.getCode());
                                    if (DraftEnum.fromCode(request.getEncouragementDraft()).equals(DraftEnum.Sent))
                                        encouragement.setEncouragementSentDraftDate(LocalDate.now());
                                }
                            }

                            if (request.getAmount() != null)
                                encouragement.setEncouragementAmount(request.getAmount());
                            if (request.getDescription() != null)
                                encouragement.setEncouragementDescription(request.getDescription());
                            if (request.getAmountType() != null)
                                encouragement.setEncouragementAmountType(request.getAmountType());
                            if (registrar.getPersonnelOrganizationID() != null)
                                encouragement.setEncouragementRegistrarOrganizationId(registrar.getPersonnelOrganizationID());
                            if (personnelOrganizationId != null)
                                encouragement.setEncouragementPersonnelOrganizationId(personnelOrganizationId);
                            if (request.getEncouragementDraft() != null) {
                                encouragement.setEncouragementDraft(DraftEnum.fromCode(request.getEncouragementDraft()));
                            }
                            if (reasonType != null && reasonType.getEncouragementReasonTypeId() != null)
                                encouragement.setEncouragementReasonTypeId(reasonType.getEncouragementReasonTypeId());
//                            if (isDraft) {
//                                encouragement.setEncouragementStatus(EncouragementResultEnum.DRAFT.getCode());
//                            } else {
//                                encouragement.setEncouragementStatus(EncouragementResultEnum.UNDER_REVIEW.getCode());
//                            }

                            encouragements.add(encouragement);
                        } else throw new GeneralException("فرد تشویق کننده می بایست جزو مدیران تشویق شونده باشد .");
                    } else throw new GeneralException("فرد تشویق کننده و فرد تشویق شونده می بایست در یک یگان باشند .");
                }
                List<Encouragement> resultList = encouragementRepository.saveAll(encouragements);
                if (!resultList.isEmpty() && request.getEncouragementDraft().equals(DraftEnum.Sent.getCode())) {
                    resultList.forEach(encouragement -> {
                        try {
                            if (request.getEncouragementDraft() != null && request.getEncouragementDraft().equals(DraftEnum.Sent.getCode())) {
                                if (encouragement.getEncouragementStatus().equals(ReviewResultEnum.SENT_FOR_CORRECTION.getCode())) {
                                    EncouragementReview encouragementReview = encouragementReviewService.getReviewOfThisRegistrarThisEncouragement(encouragement.getEncouragementRegistrarOrganizationId(), encouragement.getEncouragementId());
                                    if (encouragementReview != null)
                                        encouragementReviewService.changeEncouragementReviewStatus(encouragementReview, ReviewResultEnum.APPROVED.getCode());
                                    changeEncouragementStatus(encouragement, ReviewResultEnum.UNDER_REVIEW.getCode(), DraftEnum.fromCode(request.getEncouragementDraft()));
                                    this.calculator(encouragement, request.getType().getTypeId(), registrar, Boolean.TRUE, request.getEncouragementDraft());
                                } else
                                    this.calculator(encouragement, request.getType().getTypeId(), registrar, Boolean.FALSE, request.getEncouragementDraft());
                            }
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    });
                }
                return resultList;
            } else throw new GeneralException(" تشویق بالاتر از حداکثر  مجاز تعیین شده می باشد . ");
        } else throw new GeneralException("پارامتر ورودی صحیح نمی باشد .");
    }


    @Transactional
    protected void calculator(Encouragement encouragement, UUID typeId, PersonnelDTO personnelReviewCreator, Boolean isUpdateMode, Integer draft) throws Exception {
        if (encouragement != null) {
            PersonnelDTO encouragedPerson = personnelService.findByOrganizationId(encouragement.getEncouragementPersonnelOrganizationId());
            if (encouragedPerson != null) {
//                PersonnelDto registrar = personnelService.findByOrganizationId(encouragement.getEncouragementRegistrarOrganizationId());
                if (personnelReviewCreator != null) {
                    /**  @CheckVedjaCondition */
                    Integer encouragedPersonRank = encouragedPerson.getPersonnelRankTypeCode();
                    boolean isGreaterThanSecondLieutenant = encouragedPersonRank >= RankTypeEnum.SECOND_LIEUTENANT.getRankCode();
                    if (!(isGreaterThanSecondLieutenant)) {
                        boolean hasPowerLimit = registrarPowerLimitsService.existsByRankTypeCodeAndPositionCode(encouragedPerson.getPersonnelRankTypeCode(), personnelReviewCreator.getPersonnelJobPositionCode(), typeId);
                        if (hasPowerLimit) {
                            boolean amountOfEncouragementIsWithinThePowerLimits = false;
                            RegistrarPowerLimits powerLimits = registrarPowerLimitsService.findByRankTypeCodeAndPositionCodeAndTypeId(encouragedPerson.getPersonnelRankTypeCode(), personnelReviewCreator.getPersonnelJobPositionCode(), typeId);
                            if ((encouragement.getEncouragementAmount() == null && powerLimits.getMaxAmount() == null)) {
                                amountOfEncouragementIsWithinThePowerLimits = true;
                            } else {
                                if (encouragement.getEncouragementAmount() != null && powerLimits.getMaxAmount().compareTo(BigDecimal.valueOf(encouragement.getEncouragementAmount())) >= 0) {
                                    amountOfEncouragementIsWithinThePowerLimits = true;
                                }
                            }
                            if (amountOfEncouragementIsWithinThePowerLimits) {
                                this.changeEncouragementStatus(encouragement, EncouragementResultEnum.APPROVED.getCode(), null);
                            } else {
                                this.changeEncouragementStatus(encouragement, EncouragementResultEnum.NEED_FOR_ACCEPT.getCode(), null);
                                if (!encouragedPerson.getPersonnelManager().isEmpty()) {
                                    //find related manager with job position
                                    Optional<Integer> level = encouragedPerson.getPersonnelManager()
                                            .stream()
                                            .sorted(Comparator.comparingInt(PersonnelManagerDTO::getPersonnelManagerLevel))
                                            .toList()
                                            .stream()
                                            .filter(manager -> JobPositionEnum.fromCode(personnelReviewCreator.getPersonnelJobPositionCode()).equals(JobPositionEnum.fromCode(Integer.parseInt(manager.getPersonnelManagerPosition())))).map(PersonnelManagerDTO::getPersonnelManagerLevel).findAny();
                                    Optional<PersonnelManagerDTO> nextManager = Optional.empty();
                                    if (level.isPresent()) {
                                        Integer i = level.get();
                                        nextManager = encouragedPerson.getPersonnelManager().stream().filter(personnelManagerDTO -> personnelManagerDTO.getPersonnelManagerLevel().equals(i + 1)).findAny();
                                    }
                                    if (nextManager.isPresent()) {
                                        PersonnelManagerDTO managerDTO = nextManager.get();
                                        this.createReviewFromEncouragement(encouragement, managerDTO.getPersonnelManagerOrganizationId(), ReviewResultEnum.UNDER_REVIEW.getCode(), ReviewTypeEnum.ORDINARY_REVIEWER.getCode(), DraftEnum.Nothing.getCode());
                                    } else {
                                        this.createReviewFromEncouragement(encouragement, "67963", ReviewResultEnum.UNDER_REVIEW.getCode(), ReviewTypeEnum.ORDINARY_COMMISSION.getCode(), DraftEnum.Nothing.getCode());
                                    }
                                } else throw new GeneralException("لیست مدیران شخص وارد شده خالی می باشد .");
                            }
                        } else {
                            if (!isUpdateMode) {
                                this.createReviewFromEncouragement(encouragement, personnelReviewCreator.getPersonnelOrganizationID(), ReviewResultEnum.APPROVED.getCode(), ReviewTypeEnum.ORDINARY_REVIEWER.getCode(), DraftEnum.Sent.getCode());
                            }
                            if (!encouragedPerson.getPersonnelManager().isEmpty()) {
                                //find related manager with job position
                                Optional<Integer> level = encouragedPerson.getPersonnelManager()
                                        .stream()
                                        .sorted(Comparator.comparingInt(PersonnelManagerDTO::getPersonnelManagerLevel))
                                        .toList()
                                        .stream()
                                        .filter(manager -> JobPositionEnum.fromCode(personnelReviewCreator.getPersonnelJobPositionCode()).equals(JobPositionEnum.fromCode(Integer.parseInt(manager.getPersonnelManagerPosition())))).map(PersonnelManagerDTO::getPersonnelManagerLevel).findAny();
                                Optional<PersonnelManagerDTO> nextManager = Optional.empty();
                                if (level.isPresent()) {
                                    Integer i = level.get();
                                    nextManager = encouragedPerson.getPersonnelManager().stream().filter(personnelManagerDTO -> personnelManagerDTO.getPersonnelManagerLevel().equals(i + 1)).findAny();
                                }
                                if (nextManager.isPresent()) {
                                    PersonnelManagerDTO managerDTO = nextManager.get();
                                    this.createReviewFromEncouragement(encouragement, managerDTO.getPersonnelManagerOrganizationId(), ReviewResultEnum.UNDER_REVIEW.getCode(), ReviewTypeEnum.ORDINARY_REVIEWER.getCode(), DraftEnum.Nothing.getCode());
                                } else {
                                    String[] commissionPersonnelList = commissionList.split(",");
                                    Arrays.stream(commissionPersonnelList).forEach(commissionOrgId ->
                                            this.createReviewFromEncouragement(encouragement, commissionOrgId, ReviewResultEnum.UNDER_REVIEW.getCode(), ReviewTypeEnum.ORDINARY_COMMISSION.getCode(), DraftEnum.Nothing.getCode()));
                                }
                            } else throw new GeneralException("لیست مدیران شخص وارد شده خالی می باشد .");
                        }
                    } else {
                        this.createReviewFromEncouragement(encouragement, "64763", ReviewResultEnum.UNDER_REVIEW.getCode(), ReviewTypeEnum.VEDJA_COMMISSION.getCode(), DraftEnum.Nothing.getCode());
                    }
                } else throw new GeneralException("شخص تشویق کننده یافت نشد .");
            } else throw new GeneralException("شخص تشویق شونده یافت نشد .");
        } else throw new GeneralException("پارامتر ورودی صحیح نمی باشد .");
    }

    @Transactional
    protected void createReviewFromEncouragement(Encouragement encouragement, String registrarOrganizationId, Integer result, Integer type, Integer draft) {
        EncouragementReview encouragementReview = new EncouragementReview();
        encouragementReview.setEncouragementReviewEncouragementId(encouragement.getEncouragementId());
        encouragementReview.setEncouragementReviewType(type);
        encouragementReview.setEncouragementReviewEncouragementTypeId(encouragementTypeService.findIdByReasonTypeId(encouragement.getEncouragementReasonTypeId()));
        encouragementReview.setEncouragementReviewAmount(encouragement.getEncouragementAmount() != null ? Double.valueOf(encouragement.getEncouragementAmount()): null);
        encouragementReview.setEncouragementReviewAmountType(encouragement.getEncouragementAmountType());
//        encouragementReview.setEncouragementReviewDescription(encouragement.getEncouragementDescription());
        encouragementReview.setEncouragementReviewRegistrarOrganizationId(registrarOrganizationId);
//                    TODO type id is not exists in encouragement
//          encouragementReview.setEncouragementReviewEncouragementTypeId(encouragement.getEncouragementTypeId());
        encouragementReview.setEncouragementReviewResult(result);
        if (draft != null) {
            encouragementReview.setEncouragementReviewDraft(DraftEnum.fromCode(draft));
            if (draft.equals(DraftEnum.Sent.getCode()))
                encouragementReview.setEncouragementReviewSentDraftDate(LocalDate.now());
        }
        encouragementReview.setEncouragementReviewCreatedAt(LocalDateTime.now());
        encouragementReviewService.add(encouragementReview);
    }


    private UUID findReasonTypeId(UUID reasonId, UUID typeId) {
        return encouragementReasonTypeRepository.findByEncouragementReasonIdAndEncouragementTypeId(reasonId, typeId).map(EncouragementReasonType::getEncouragementReasonTypeId).orElseThrow(() -> new RuntimeException("Reason Type not found for Reason ID: " + reasonId + " and Type ID: " + typeId));
    }

    private EncouragementReasonType findReasonType(UUID reasonId, UUID typeId) {
        return encouragementReasonTypeRepository.findByEncouragementReasonIdAndEncouragementTypeId(reasonId, typeId).orElseThrow(() -> new GeneralException("ارتباط نوع و علت یافت نشد . "));
    }


    private String generateEncouragementNumber() {
        return String.format("%015d", ThreadLocalRandom.current().nextInt(1000000000));
    }


    public void deleteEncouragement(UUID id) {
        encouragementRepository.deleteById(id);
    }


//    public Encouragement updateEncouragement(UUID id, EncouragementCreateRequestSpecial request) {
//        Encouragement encouragement = null;
//        if (id != null)
//            encouragement = encouragementRepository.findById(id).orElseThrow(() -> new GeneralException("Encouragement not found"));
//        if (encouragement != null) {
////            encouragement.setEncouragementRegistrarPersonnelId(request.getEncouragementRegistrarPersonnelId());
//            setNonNullFieldsFromDto(request, encouragement);
//        }else {
//            encouragement= new Encouragement();
//            //            encouragement.setEncouragementRegistrarPersonnelId(request.getEncouragementRegistrarPersonnelId());
//            setNonNullFieldsFromDto(request, encouragement);
//        }
////        EncouragementDTO encouragementDTO = this.convertToEncouragementDTO(encouragement);
////        this.encouragementCalculator(encouragementDTO);
//        return encouragementRepository.save(encouragement);
//    }

//    private void setNonNullFieldsFromDto(EncouragementCreateRequestSpecial request, Encouragement encouragement) {
//        UUID reasonTypeId = null;
//        if (request.getReasonId() != null && request.getType() != null && request.getType().getTypeId() != null)
//            reasonTypeId = findReasonTypeId(request.getReasonId(), request.getType().getTypeId());
//        if (reasonTypeId != null)
//            encouragement.setEncouragementReasonTypeId(reasonTypeId);
//        if (request.getDescription() != null)
//            encouragement.setEncouragementDescription(request.getDescription());
//        if (request.getAmount() != null) {
//            Long amount = request.getAmount() != null ? request.getAmount() : 0L;
//            encouragement.setEncouragementAmount(amount);
//        }
//        if (request.getAmountType() != null) {
//            Integer amountType = request.getAmountType() != null ? request.getAmountType() : 0;
//            encouragement.setEncouragementAmountType(amountType);
//        }
////            Integer status = request.getStatus() != null ? request.getStatus() : 0;
////            encouragement.setEncouragementStatus(status);
//        if (request.getEncouragementDraft() != null)
//            encouragement.setEncouragementDraft(DraftEnum.fromCode(request.getEncouragementDraft()));
//        if (request.getEncouragementDraft().equals(DraftEnum.Sent.getCode()))
//            encouragement.setEncouragementSentDraftDate(LocalDateTime.now());
//    }

    @Transactional
    public void changeEncouragementStatus(Encouragement encouragement, Integer status, DraftEnum draftEnum) {
//        if (encouragementRepository.existsById(encouragementId)) {
        if (encouragement != null) {
//            Encouragement encouragement = encouragementRepository.findById(encouragementId).orElseThrow();
            encouragement.setEncouragementStatus(status);
            if (draftEnum != null)
                encouragement.setEncouragementDraft(draftEnum);
            encouragement.setEncouragementAppliedDate(LocalDate.now());
            encouragementRepository.save(encouragement);
        }
    }


    /**
     * @Mappers ------------------------------------------------------------------------------------
     */


    private void mapEntityToDTO(Encouragement encouragement, EncouragementFilterDTOV2 encouragementDTO) {
        encouragementDTO.setEncouragementReasonTypeId(encouragement.getEncouragementReasonTypeId());
        encouragementDTO.setEncouragementId(encouragement.getEncouragementId());
        encouragementDTO.setEncouragementAmount(encouragement.getEncouragementAmount());
        encouragementDTO.setEncouragementRegistrarOrganizationId(encouragement.getEncouragementRegistrarOrganizationId());
        encouragementDTO.setEncouragementDescription(encouragement.getEncouragementDescription());
        encouragementDTO.setEncouragementNumber(encouragement.getEncouragementNumber());
        encouragementDTO.setEncouragementStatus(encouragement.getEncouragementStatus());
        encouragementDTO.setEncouragementAmountType(encouragement.getEncouragementAmountType());
        encouragementDTO.setCreatedAt(encouragement.getEncouragementCreatedAt());
        encouragementDTO.setEncouragementAppliedDate(encouragement.getEncouragementAppliedDate() != null ? encouragement.getEncouragementAppliedDate() : null);
        encouragementDTO.setEncouragementSentDraftDate(encouragement.getEncouragementSentDraftDate() != null ? encouragement.getEncouragementSentDraftDate() : null);
        encouragementDTO.setEncouragementDraft(encouragement.getEncouragementDraft() != null ? encouragement.getEncouragementDraft().getCode(): null);
    }


    private EncouragementDTO convertToEncouragementDTO(Encouragement encouragement) throws ExecutionException, InterruptedException {
        EncouragementDTO dto = new EncouragementDTO();
        dto.setEncouragementId(encouragement.getEncouragementId());
        UUID reasonTypeId = encouragement.getEncouragementReasonTypeId();
//        if (encouragement.getEncouragementPersonnelOrganizationId() != null) {
//            PersonnelDTO personnelDTO = personnelService.findByOrganizationId(encouragement.getEncouragementPersonnelOrganizationId());
//            if (personnelDTO != null) {
//                dto.setEncouragementPersonnelDTO(personnelDTO);
//            }
//
//        }


//        if (encouragement.getEncouragementRegistrarOrganizationId() != null) {
//            PersonnelDTO personnelDTO = personnelService.findByOrganizationId(encouragement.getEncouragementRegistrarOrganizationId());
//            if (personnelDTO != null) {
//                dto.setEncouragementRegistrarPersonnelDTO(personnelDTO);
//            }
//        }


//        if (encouragement.getEncouragementApproverOrganizationId() != null) {
//            PersonnelDTO personnelDTO = personnelService.findByOrganizationId(encouragement.getEncouragementApproverOrganizationId());
//            if (personnelDTO != null) {
//                dto.setEncouragementApproverPersonnelDTO(personnelDTO);
//
//            }
//        }


//        dto.setEncouragementRelatedPersonnelId(List.of(encouragement.getEncouragementRelatedPersonnelId()));
//        dto.setEncouragementRegistrarPersonnelId(encouragement.getEncouragementRegistrarPersonnelId());
//        dto.setEncouragementApproverPersonnelId(encouragement.getEncouragementApproverPersonnelId());
        dto.setEncouragementReasonTypeId(reasonTypeId);
        dto.setEncouragementNumber(encouragement.getEncouragementNumber());
        dto.setEncouragementCreatedAt(encouragement.getEncouragementCreatedAt());
        dto.setEncouragementAmount(encouragement.getEncouragementAmount());
        dto.setEncouragementAmountType(encouragement.getEncouragementAmountType());
        dto.setEncouragementDescription(encouragement.getEncouragementDescription());
        dto.setEncouragementStatus(encouragement.getEncouragementStatus());
        dto.setEncouragementAppliedDate(encouragement.getEncouragementAppliedDate());
        dto.setEncouragementRegistrarOrganizationId(encouragement.getEncouragementRegistrarOrganizationId());
        EncouragementReasonTypeDetailDTO reasonTypeDetails = fetchReasonTypeDetails(reasonTypeId);
        dto.setEncouragementReasonId(reasonTypeDetails.getEncouragementReasonId());  // reasonId
        dto.setEncouragementTypeId(reasonTypeDetails.getEncouragementTypeId());      // typeId
        dto.setMaxAmount(reasonTypeDetails.getMaxAmount());
        dto.setMaxDuration(reasonTypeDetails.getMaxDuration());
        dto.setDurationType(reasonTypeDetails.getDurationType());
        dto.setEncouragementAmountType(encouragement.getEncouragementAmountType());
        dto.setEncouragementReasonTitle(reasonTypeDetails.getEncouragementReasonTitle());
        dto.setEncouragementTypeTitle(reasonTypeDetails.getEncouragementTypeTitle());
        dto.setMaxAmount(reasonTypeDetails.getMaxAmount());
        dto.setMaxDuration(reasonTypeDetails.getMaxDuration());
        dto.setDurationType(reasonTypeDetails.getDurationType());
        dto.setEncouragementDraft(encouragement.getEncouragementDraft().getCode());
        dto.setEncouragementSentDraftDate(encouragement.getEncouragementSentDraftDate());
        dto.setDurationType(reasonTypeDetails.getDurationType());
        return dto;
    }


    @Transactional
    public EncouragementReviewDTO updateEncouragementReview(EncouragementReviewUpdateDTO dto) throws Exception {
        EncouragementReview entity = encouragementReviewService.findById(dto.getEncouragementReviewId());
        if (entity.getEncouragementReviewDraft() != null && entity.getEncouragementReviewDraft().equals(DraftEnum.Sent))
            throw new GeneralException("این بررسی تشویق ارسال شده و قابل ویرایش نمی باشد.");
        Encouragement encouragement = encouragementRepository.findById(entity.getEncouragementReviewEncouragementId()).orElseThrow(() -> new GeneralException("تشویق مورد نظر یافت نشد. "));
        if (entity.getEncouragementReviewType().equals(ReviewTypeEnum.ORDINARY_COMMISSION.getCode())){
            List<EncouragementReview> reviewDTOList = encouragementReviewService.getAllCommissionReviewsForThisEncouragement(encouragement.getEncouragementId());
            reviewDTOList.forEach(encouragementReview -> {
                try {
                    updateEachEncouragementReviewThatNeeded(dto, encouragementReview, encouragement);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            });
        }
        return updateEachEncouragementReviewThatNeeded(dto, entity, encouragement);
    }

    private EncouragementReviewDTO updateEachEncouragementReviewThatNeeded(EncouragementReviewUpdateDTO dto, EncouragementReview entity, Encouragement encouragement) throws Exception {
        TblUser user = authService.getIsLoginUser();
        Integer roleCode = user.getRoles().get(0).get("encouragement_user_role");
        if (dto.getEncouragementAmount() != null) {
//            if (roleCode.equals(RoleConstant.ROLE.COMMISSION.getValue()) || roleCode.equals(RoleConstant.ROLE.VEDJA.getValue())) {
                encouragement.setEncouragementAmount(dto.getEncouragementAmount());
//                entity.setEncouragementReviewAmount(Double.valueOf(dto.getEncouragementAmount()));
                encouragementRepository.save(encouragement);
//            } else
//                throw new GeneralException("فقط مدیر کمیسیون و ودجا می توانند مقدار را تغییر دهند.");
        }
        EncouragementReasonType reasonType = encouragementReasonTypeService.findById(encouragement.getEncouragementReasonTypeId());
        if (dto.getEncouragementReviewResult() != null && dto.getEncouragementReviewResult().equals(ReviewResultEnum.APPROVED.getCode())) {
            if (dto.getEncouragementReviewDraft().equals(DraftEnum.Sent.getCode())) {
                if (reasonType != null && reasonType.getEncouragementTypeId() != null) {
                    PersonnelDTO currentUser = personnelService.findByOrganizationId(authService.getIsLoginUser().getUsername());
                    this.calculator(encouragement, reasonType.getEncouragementTypeId(), currentUser, Boolean.TRUE, null);
                    entity.setEncouragementReviewSentDraftDate(LocalDate.now());
                }
            }
        } else if (dto.getEncouragementReviewResult() != null && dto.getEncouragementReviewResult().equals(ReviewResultEnum.REJECTED.getCode())) {
            if (dto.getEncouragementReviewDraft().equals(DraftEnum.Sent.getCode())) {
                if (reasonType != null && reasonType.getEncouragementTypeId() != null) {
                    entity.setEncouragementReviewSentDraftDate(LocalDate.now());
                }
            }
            this.changeEncouragementStatus(encouragement, EncouragementResultEnum.REJECTED.getCode(), null);
        } else if (dto.getEncouragementReviewResult() != null && dto.getEncouragementReviewResult().equals(EncouragementResultEnum.SENT_FOR_CORRECTION.getCode())) {
            if (dto.getEncouragementReviewDraft().equals(DraftEnum.Sent.getCode())) {
                if (reasonType != null && reasonType.getEncouragementTypeId() != null) {
                    entity.setEncouragementReviewSentDraftDate(LocalDate.now());
                }
                entity.setEncouragementReviewResult(EncouragementResultEnum.SENT_FOR_CORRECTION.getCode());
                EncouragementReview encouragementReview = new EncouragementReview();
                encouragementReview.setEncouragementReviewResult(EncouragementResultEnum.UNDER_REVIEW.getCode());
                encouragementReview.setEncouragementReviewRegistrarOrganizationId(encouragement.getEncouragementRegistrarOrganizationId());
                encouragementReview.setEncouragementReviewEncouragementId(encouragement.getEncouragementId());
                encouragementReview.setEncouragementReviewEncouragementTypeId(entity.getEncouragementReviewEncouragementTypeId());
                encouragementReview.setEncouragementReviewAmount(Double.valueOf(encouragement.getEncouragementAmount()));
                encouragementReview.setEncouragementReviewAmountType(encouragement.getEncouragementAmountType());
                changeEncouragementStatus(encouragement, EncouragementResultEnum.SENT_FOR_CORRECTION.getCode(), DraftEnum.RegisterAndClose);
                encouragementReviewService.add(encouragementReview);
            }
        }
        updateNonNullFields(dto, entity);
        EncouragementReview result = encouragementReviewService.add(entity);
        return encouragementReviewService.convertToDTO(result);
    }

    private void updateNonNullFields(EncouragementReviewUpdateDTO dto, EncouragementReview entity) {
        if (dto.getEncouragementReviewId() != null)
            entity.setEncouragementReviewId(dto.getEncouragementReviewId());
        if (dto.getEncouragementReviewDescription() != null)
            entity.setEncouragementReviewDescription(dto.getEncouragementReviewDescription());
        if (dto.getEncouragementReviewDraft() != null)
            entity.setEncouragementReviewDraft(DraftEnum.fromCode(dto.getEncouragementReviewDraft()));
//        if (dto.getEncouragementReviewApprovalDate() != null)
//            entity.setEncouragementReviewSentDraftDate(dto.getEncouragementReviewApprovalDate());
        if (dto.getEncouragementReviewResult() != null)
            entity.setEncouragementReviewResult(dto.getEncouragementReviewResult());
        entity.setEncouragementReviewUpdatedAt(LocalDateTime.now());
        entity.setEncouragementReviewAppliedDate(dto.getEncouragementReviewAppliedDate());
    }


    public PageImpl<EncouragementReviewDTO> getAllEncouragementReviews(EncouragementReviewSearchDTO dto, PageRequest pageRequest) throws Exception {
        List<EncouragementReviewDTO> dtoList= new ArrayList<>();
        dto.setEncouragementReviewRegistrarOrgIdNotEncouragementRegistrarOrgId(authService.getIsLoginUser().getUsername());
        if (dto.getEncouragementReviewEncouragedLastName() != null){
            List<PersonnelDTO> list = personnelService.getFilteredPersonnel(PersonnelFilterDTOV2.builder().personnelLastName(dto.getEncouragementReviewEncouragedLastName()).type("basePersonnel").build());
            if (list != null) {
                Optional<PersonnelDTO> optional = list.stream().findFirst();
                if (optional.isPresent()) {
                    PersonnelDTO personnelDTO = optional.get();
                    dto.setEncouragementReviewEncouragedOrganizationId(personnelDTO.getPersonnelOrganizationID());
                }else
                    return new PageImpl<>(dtoList, pageRequest, 0);
            }
        }
        if (dto.getEncouragementReviewEncouragedRegistrarLastName() != null){
            List<PersonnelDTO> list = personnelService.getFilteredPersonnel(PersonnelFilterDTOV2.builder().personnelLastName(dto.getEncouragementReviewEncouragedRegistrarLastName()).type("basePersonnel").build());
            if (list != null) {
                Optional<PersonnelDTO> optional = list.stream().findFirst();
                if (optional.isPresent()) {
                    PersonnelDTO personnelDTO = optional.get();
                    dto.setEncouragementReviewEncouragedRegistrarOrganizationId(personnelDTO.getPersonnelOrganizationID());
                }else
                    return new PageImpl<>(dtoList, pageRequest, 0);
            }
        }
        Page<EncouragementReview> page = encouragementReviewService.getEncouragementReviewsWithSpecification(dto, pageRequest);
        List<EncouragementReview> resultList = page.toList();
        // تبدیل نتایج به DTO ها
        dtoList = resultList.stream()
                .map(encouragementReview -> {
//                    setPageDTOFromEncouragementPage(null, null, encouragementReview);
                    UUID encouragementId = encouragementReview.getEncouragementReviewEncouragementId();
                    Optional<Encouragement> optional = encouragementRepository.findByEncouragementId(encouragementId);
                    EncouragementDTO encouragementDTO;
                    EncouragementReviewDTO encouragementReviewDTO = encouragementReviewService.convertToDTO(encouragementReview);
                    try {
                        if (optional.isPresent()) {
                            Encouragement encouragement = optional.get();
                            PersonnelDTO relatedEncouragementPersonnelDTO = personnelService.findByOrganizationIdWithType(encouragement.getEncouragementPersonnelOrganizationId(), "personnel");
                            encouragementReviewDTO.setEncouragementReviewEncouragementPersonnelDTO(relatedEncouragementPersonnelDTO);
                            PersonnelDTO registrarEncouragementPersonnelDTO = personnelService.findByOrganizationIdWithType(encouragement.getEncouragementRegistrarOrganizationId(), "personnel");
                            encouragementReviewDTO.setEncouragementReviewRegistrarPersonnelDTO(registrarEncouragementPersonnelDTO);
                            encouragementDTO = convertToEncouragementDTO(encouragement);
                            encouragementReviewDTO.setEncouragementDTO(encouragementDTO);
                        }
//                        PersonnelDTO relatedPersonnelDTO = personnelService.findByOrganizationIdWithType(encouragementReview.getEncouragementReviewRegistrarOrganizationId(), "personnel");
//                        encouragementReviewDTO.setEncouragementReviewPersonnelDTO(relatedPersonnelDTO);
                        encouragementReviewDTO.setEncouragementReviewCreatedAt(encouragementReview.getEncouragementReviewCreatedAt());
                        encouragementReviewDTO.setEncouragementReviewUpdatedAt(encouragementReview.getEncouragementReviewUpdatedAt());
                        encouragementReviewDTO.setEncouragementReviewSentDraftDate(encouragementReview.getEncouragementReviewSentDraftDate());
                        encouragementReviewDTO.setEncouragementReviewAppliedDate(encouragementReview.getEncouragementReviewAppliedDate());
                    } catch (ExecutionException | InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    return encouragementReviewDTO;
                })
                .collect(Collectors.toList());
        return new PageImpl<>(dtoList, pageRequest, dtoList.size());
    }
}
