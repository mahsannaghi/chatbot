package com.paya.EncouragementService.repository;

import com.paya.EncouragementService.entity.Encouragement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;


@Repository
public interface EncouragementRepository extends JpaRepository<Encouragement, UUID>, JpaSpecificationExecutor<Encouragement> {


    boolean existsByEncouragementReasonTypeId(UUID reasonTypeId);

    Optional<Encouragement> findByEncouragementReasonTypeId(UUID reasonTypeId);
    Optional<Encouragement> findByEncouragementId(UUID uuid);
//    Page<Encouragement> findByEncouragementRelatedPersonnelOrganizationId(List<String> orgIdList, Pageable pageable);
//    Page<Encouragement> findByEncouragementRelatedPersonnelOrganizationId(String orgId, Pageable pageable);



}


